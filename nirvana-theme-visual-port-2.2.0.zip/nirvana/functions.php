<?php
if(!defined('ABSPATH')){exit;}
const NIRVANA_THEME_VERSION='2.2.0';
require_once get_template_directory().'/inc/theme-experience.php';
add_action('after_setup_theme',function(){add_theme_support('title-tag');add_theme_support('post-thumbnails');add_theme_support('responsive-embeds');add_theme_support('html5',array('search-form','gallery','caption','style','script'));add_theme_support('custom-logo',array('flex-height'=>true,'flex-width'=>true));register_nav_menus(array('primary'=>__('Primary Navigation','nirvana')));});
add_action('wp_enqueue_scripts',function(){wp_enqueue_style('nirvana-visual-port',get_stylesheet_uri(),array(),NIRVANA_THEME_VERSION);wp_enqueue_script('nirvana-shell',get_template_directory_uri().'/assets/js/theme-main.js',array(),NIRVANA_THEME_VERSION,true);wp_localize_script('nirvana-shell','nirvanaThemeUI',array('search_url'=>esc_url_raw(rest_url('nirvana-theme/v1/search')),'searching'=>__('Searching…','nirvana'),'no_results'=>__('No matching published content was found.','nirvana'),'error'=>__('Search is temporarily unavailable.','nirvana')));if(is_page_template('page-contact.php')){wp_enqueue_script('nirvana-contact',get_template_directory_uri().'/assets/js/contact-form.js',array(),NIRVANA_THEME_VERSION,true);wp_localize_script('nirvana-contact','nirvanaContactForm',array('rest_url'=>esc_url_raw(rest_url('nirvana/v1/inquiries')),'default_subject'=>__('New Website Inquiry','nirvana'),'success'=>__('Your inquiry was received.','nirvana'),'error'=>__('The inquiry could not be sent. Please try again.','nirvana'),'reference'=>__('Reference:','nirvana'),'contact_required'=>__('Enter an email address or phone number.','nirvana')));}});
function nirvana_page_url($slug){$page=get_page_by_path($slug);return $page?get_permalink($page):home_url('/'.trim($slug,'/').'/');}
function nirvana_blog_url(){$id=absint(get_option('page_for_posts'));return $id?get_permalink($id):nirvana_page_url('blog');}
function nirvana_scene_asset(){if(is_front_page())return array('video'=>nirvana_media_url('video_home',get_template_directory_uri().'/assets/videos/bg-home.mp4'),'class'=>'scene--home');if(is_page_template('page-about.php'))return array('video'=>nirvana_media_url('video_about',get_template_directory_uri().'/assets/videos/bg-1.mp4'),'class'=>'scene--about');if(is_post_type_archive('nirvana_tile')||is_singular('nirvana_tile'))return array('video'=>nirvana_media_url('video_gallery',get_template_directory_uri().'/assets/videos/bg-2.mp4'),'class'=>'scene--gallery');return array('video'=>'','class'=>'scene--poster');}
function nirvana_overlay_menu(){
 $items=array(
  array(nirvana_mod('nav_home','Home'),'Landing & 3D Scene',home_url('/'),'⌂',is_front_page()),
  array(nirvana_mod('nav_about','About Us'),'Philosophy & Logistics',nirvana_page_url('about'),'i',is_page_template('page-about.php')),
  array(nirvana_mod('nav_gallery','Gallery'),'Architectural Tiles',get_post_type_archive_link('nirvana_tile')?:home_url('/tiles/'),'▦',is_post_type_archive('nirvana_tile')||is_singular('nirvana_tile')),
  array(nirvana_mod('nav_calculator','Tile Calculator'),'Estimate Quantities','','#',false),
  array(nirvana_mod('nav_blog','Blog'),'Supply Strategy',nirvana_blog_url(),'✎',is_home()||is_singular('post')),
  array(nirvana_mod('nav_contact','Contacts'),'Office & Inquiries',nirvana_page_url('contact'),'@',is_page_template('page-contact.php')),
 );
 echo '<nav class="menu-grid" aria-label="'.esc_attr__('Primary Navigation','nirvana').'">';
 foreach($items as $i=>$item){$inner='<span class="menu-item-top"><span class="menu-icon">'.esc_html($item[3]).'</span><span class="menu-no">0'.esc_html($i+1).'</span></span><span><strong>'.esc_html($item[0]).'</strong><small>'.esc_html($item[1]).'</small></span>';if(3===$i)echo '<button class="menu-item" type="button" data-calculator-open>'.$inner.'</button>';else echo '<a class="menu-item'.($item[4]?' current':'').'" href="'.esc_url($item[2]).'">'.$inner.'</a>';}
 echo '<button class="menu-item" type="button" data-search-open><span class="menu-item-top"><span class="menu-icon">⌕</span><span class="menu-no">07</span></span><span><strong>'.esc_html(nirvana_mod('nav_search','Search')).'</strong><small>'.esc_html__('Products & Specs','nirvana').'</small></span></button></nav>';
}
function nirvana_public_facets(){
 $cached=get_transient('nirvana_public_facets_v2');if(false!==$cached&&is_array($cached))return $cached;
 $out=array('factories'=>array(),'sizes'=>array(),'thicknesses'=>array(),'bodies'=>array(),'finishes'=>array());if(!function_exists('nirvana_get_tile_variant_pairs'))return $out;
 $ids=get_posts(array('post_type'=>'nirvana_tile','post_status'=>'publish','fields'=>'ids','posts_per_page'=>200,'no_found_rows'=>true));foreach($ids as $id){$pairs=nirvana_get_tile_variant_pairs($id,true);if(!$pairs)continue;$factory=absint(get_post_meta($id,'_nirvana_tile_factory_id',true));if($factory&&'publish'===get_post_status($factory))$out['factories'][$factory]=get_the_title($factory);foreach($pairs as $pair){$sid=absint($pair['size_id']??0);$tid=absint($pair['thickness_id']??0);if($sid)$out['sizes'][$sid]=$pair['size_label']??get_the_title($sid);if($tid)$out['thicknesses'][$tid]=$pair['thickness_label']??'';}foreach(array('bodies'=>'nirvana_body','finishes'=>'nirvana_finish') as $key=>$tax){$terms=wp_get_post_terms($id,$tax);if(!is_wp_error($terms))foreach($terms as $term)$out[$key][$term->slug]=$term->name;}}
 foreach($out as &$values){asort($values,SORT_NATURAL|SORT_FLAG_CASE);}set_transient('nirvana_public_facets_v2',$out,15*MINUTE_IN_SECONDS);return $out;
}
function nirvana_breadcrumbs(){if(is_front_page())return;echo '<nav class="breadcrumbs" aria-label="'.esc_attr__('Breadcrumb','nirvana').'"><a href="'.esc_url(home_url('/')).'">'.esc_html__('Home','nirvana').'</a> / ';if(is_singular('nirvana_tile'))echo '<a href="'.esc_url(get_post_type_archive_link('nirvana_tile')).'">'.esc_html__('Gallery','nirvana').'</a> / '.esc_html(get_the_title());elseif(is_singular('post'))echo '<a href="'.esc_url(nirvana_blog_url()).'">'.esc_html__('Blog','nirvana').'</a> / '.esc_html(get_the_title());else echo esc_html(wp_get_document_title());echo '</nav>';}
add_action('pre_get_posts',function($q){if(!is_admin()&&$q->is_main_query()&&$q->is_search()){$q->set('post_type',array('post','page','nirvana_tile'));$q->set('post_status','publish');}});
add_action('after_switch_theme','nirvana_create_core_pages');
add_action('admin_init',function(){if(get_option('nirvana_visual_port_version')!==NIRVANA_THEME_VERSION){nirvana_create_core_pages();update_option('nirvana_visual_port_version',NIRVANA_THEME_VERSION);}});
function nirvana_create_core_pages(){
 $pages=array('home'=>array('Home',''),'about'=>array('About Us','page-about.php'),'contact'=>array('Contact','page-contact.php'),'calculator'=>array('Calculator','page-calculator.php'),'blog'=>array('Blog',''));
 $ids=array();foreach($pages as $slug=>$cfg){$p=get_page_by_path($slug);if(!$p){$id=wp_insert_post(array('post_title'=>$cfg[0],'post_name'=>$slug,'post_type'=>'page','post_status'=>'publish','post_content'=>''),true);if(is_wp_error($id))continue;}else{$id=$p->ID;}if($cfg[1])update_post_meta($id,'_wp_page_template',$cfg[1]);$ids[$slug]=$id;}
 if(!empty($ids['home'])&&!empty($ids['blog'])){update_option('show_on_front','page');update_option('page_on_front',$ids['home']);update_option('page_for_posts',$ids['blog']);}flush_rewrite_rules(false);
}
add_action('wp_head',function(){if(is_admin())return;$description=get_bloginfo('description');if(is_singular()){$post=get_post();$description=$post&&$post->post_excerpt?$post->post_excerpt:($post?wp_trim_words(wp_strip_all_tags($post->post_content),24):$description);}if($description)echo '<meta name="description" content="'.esc_attr($description).'">'."\n";},2);


/** Render the plugin calculator once during enqueue so its assets print in wp_head. */
add_action('wp_enqueue_scripts','nirvana_prepare_modal_calculator',20);
function nirvana_prepare_modal_calculator(){
 $GLOBALS['nirvana_modal_calculator']='';
 if(shortcode_exists('nirvana_calculator')){$GLOBALS['nirvana_modal_calculator']=do_shortcode('[nirvana_calculator title="Project Tile Calculator"]');}
}

add_action('rest_api_init',function(){register_rest_route('nirvana-theme/v1','/search',array('methods'=>WP_REST_Server::READABLE,'callback'=>'nirvana_live_search','permission_callback'=>'__return_true','args'=>array('q'=>array('required'=>true,'sanitize_callback'=>'sanitize_text_field','validate_callback'=>function($value){return is_scalar($value)&&strlen((string)$value)<=240;}))));});
function nirvana_live_search($request){
 $q=trim((string)$request->get_param('q'));if(''===$q)return rest_ensure_response(array('results'=>array()));
 $index=nirvana_search_index();
 $results=array();$terms=preg_split('/[\s,]+/u',strtolower($q),-1,PREG_SPLIT_NO_EMPTY);
 foreach($index as $row){$id=absint($row['id']);$type=get_post_type($id);$lower=$row['search'];$match=true;foreach($terms as $term){if(false===strpos($lower,remove_accents($term))){$match=false;break;}}if(!$match)continue;
  $label='nirvana_tile'===$type?__('Tile','nirvana'):('post'===$type?__('Article','nirvana'):__('Page','nirvana'));
  $results[]=array('id'=>$id,'title'=>get_the_title($id),'url'=>get_permalink($id),'type'=>$type,'label'=>$label,'description'=>wp_trim_words(wp_strip_all_tags(get_post_field('post_excerpt',$id)?:get_post_field('post_content',$id)),18));if(count($results)>=12)break;
 }
 $response=rest_ensure_response(array('results'=>$results,'count'=>count($results)));$response->header('Cache-Control','public, max-age=60');return $response;
}
