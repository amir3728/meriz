<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nirvana_mod( $key, $default = '' ) {
    $value = get_theme_mod( 'nirvana_' . $key, $default );
    return is_scalar( $value ) ? (string) $value : $default;
}
function nirvana_brand_settings() {
    $defaults = array( 'brand_name'=>'Nirvana','logo_id'=>0,'primary_color'=>'#ead654','secondary_color'=>'#183242' );
    $stored = get_option( 'nirvana_brand', array() );
    return is_array( $stored ) ? wp_parse_args( $stored, $defaults ) : $defaults;
}
function nirvana_brand_name() {
    $brand = nirvana_brand_settings();
    return $brand['brand_name'] ? sanitize_text_field( $brand['brand_name'] ) : get_bloginfo( 'name' );
}
function nirvana_brand_logo( $class = '' ) {
    $brand = nirvana_brand_settings();
    $id = absint( $brand['logo_id'] );
    if ( ! $id ) { $id = absint( get_theme_mod( 'custom_logo' ) ); }
    if ( $id && wp_attachment_is_image( $id ) ) {
        return wp_get_attachment_image( $id, 'full', false, array( 'class'=>$class, 'alt'=>nirvana_brand_name(), 'decoding'=>'async' ) );
    }
    return '<img class="'.esc_attr($class).'" src="'.esc_url(get_template_directory_uri().'/assets/images/Logo.svg').'" alt="'.esc_attr(nirvana_brand_name()).'" width="190" height="46">';
}
function nirvana_media_url( $key, $fallback = '' ) {
    $id = absint( get_theme_mod( 'nirvana_' . $key, 0 ) );
    $url = $id ? wp_get_attachment_url( $id ) : '';
    return $url ? $url : $fallback;
}
function nirvana_utility_icon( $key, $fallback_svg ) {
    $id = absint( get_theme_mod( 'nirvana_icon_' . $key, 0 ) );
    if ( $id && wp_attachment_is_image( $id ) ) {
        return wp_get_attachment_image( $id, 'thumbnail', false, array( 'class'=>'utility-icon-image', 'alt'=>'', 'aria-hidden'=>'true' ) );
    }
    return $fallback_svg;
}

add_action( 'wp_enqueue_scripts', function() {
    $brand = nirvana_brand_settings();
    $gold = sanitize_hex_color( $brand['primary_color'] ) ?: '#ead654';
    $navy = sanitize_hex_color( $brand['secondary_color'] ) ?: '#183242';
    wp_add_inline_style( 'nirvana-visual-port', ':root{--gold:'.$gold.';--navy:'.$navy.'}' );
}, 30 );

add_action( 'customize_register', function( $wp_customize ) {
    $wp_customize->add_section( 'nirvana_experience', array( 'title'=>__( 'Nirvana Experience', 'nirvana' ), 'priority'=>30, 'description'=>__( 'Edit the home message, navigation labels, motion and utility icons. Brand colors and the primary logo are managed under Nirvana Settings → Brand.', 'nirvana' ) ) );
    $text = array(
        'home_intro'=>array('From production capability validation to delivery follow-through, we help your projects move with','Home statement — before highlight'),
        'home_accent'=>array('clarity, confidence','Home statement — highlighted words'),
        'home_outro'=>array('and less risk.','Home statement — after highlight'),
        'home_primary_label'=>array('Explore Collections','Home primary button'),
        'home_secondary_label'=>array('Plan Requirements','Home calculator button'),
        'nav_home'=>array('Home','Menu: Home'), 'nav_about'=>array('About Us','Menu: About'),
        'nav_gallery'=>array('Gallery','Menu: Gallery'), 'nav_calculator'=>array('Tile Calculator','Menu: Calculator'),
        'nav_blog'=>array('Blog','Menu: Blog'), 'nav_contact'=>array('Contacts','Menu: Contact'),
        'nav_search'=>array('Search','Menu: Search')
    );
    foreach ( $text as $key=>$data ) {
        $wp_customize->add_setting( 'nirvana_'.$key, array( 'default'=>$data[0], 'sanitize_callback'=>'sanitize_text_field', 'transport'=>'refresh' ) );
        $wp_customize->add_control( 'nirvana_'.$key, array( 'section'=>'nirvana_experience', 'label'=>__( $data[1], 'nirvana' ), 'type'=>'text' ) );
    }
    $wp_customize->add_setting( 'nirvana_motion', array( 'default'=>'full', 'sanitize_callback'=>function($v){ return in_array($v,array('full','subtle','off'),true)?$v:'full'; } ) );
    $wp_customize->add_control( 'nirvana_motion', array( 'section'=>'nirvana_experience', 'label'=>__( 'Motion level', 'nirvana' ), 'type'=>'select', 'choices'=>array('full'=>'Full','subtle'=>'Subtle','off'=>'Off') ) );
    foreach ( array('calculator'=>'Calculator icon','search'=>'Search icon','menu'=>'Menu launcher icon') as $key=>$label ) {
        $wp_customize->add_setting( 'nirvana_icon_'.$key, array( 'default'=>0, 'sanitize_callback'=>'absint' ) );
        $wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'nirvana_icon_'.$key, array( 'section'=>'nirvana_experience', 'label'=>__( $label, 'nirvana' ), 'mime_type'=>'image' ) ) );
    }
    foreach ( array('video_home'=>'Home background video','video_about'=>'About background video','video_gallery'=>'Gallery background video') as $key=>$label ) {
        $wp_customize->add_setting( 'nirvana_'.$key, array( 'default'=>0, 'sanitize_callback'=>'absint' ) );
        $wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'nirvana_'.$key, array( 'section'=>'nirvana_experience', 'label'=>__( $label, 'nirvana' ), 'mime_type'=>'video' ) ) );
    }
} );

add_action( 'admin_menu', function() {
    add_theme_page( __( 'Nirvana Theme Guide','nirvana' ), __( 'Nirvana Theme Guide','nirvana' ), 'edit_theme_options', 'nirvana-theme-guide', 'nirvana_theme_guide' );
} );
function nirvana_theme_guide() {
    if ( ! current_user_can( 'edit_theme_options' ) ) { return; }
    $customize = admin_url( 'customize.php?autofocus[section]=nirvana_experience' );
    $brand = admin_url( 'admin.php?page=nirvana-settings-brand' );
    $contact = admin_url( 'admin.php?page=nirvana-settings-contact' );
    $company = admin_url( 'admin.php?page=nirvana-settings-company' );
    echo '<div class="wrap"><h1>'.esc_html__('Nirvana Theme Guide','nirvana').'</h1><p>'.esc_html__('The theme is editable without changing code. Use the right screen for each type of content.','nirvana').'</p><table class="widefat striped" style="max-width:900px"><thead><tr><th>What to edit</th><th>Where</th></tr></thead><tbody>';
    $rows=array(array('Logo, brand name and colors',$brand),array('Home message, menu labels, icons, motion and videos',$customize),array('Phones, email, messaging and address',$contact),array('About statistics and services',$company),array('Products, factories, variants and specifications',admin_url('edit.php?post_type=nirvana_tile')),array('Pages and articles',admin_url('edit.php?post_type=page')));
    foreach($rows as $row){echo '<tr><td>'.esc_html($row[0]).'</td><td><a class="button" href="'.esc_url($row[1]).'">Open editor</a></td></tr>';}
    echo '</tbody></table><p><strong>Rule:</strong> Theme updates preserve all values saved in WordPress; do not edit theme files directly.</p></div>';
}

add_filter( 'gettext', function( $translated, $text, $domain ) {
    if ( 'nirvana-tiles' !== $domain ) { return $translated; }
    $map = array(
      ('This tool produces a planning estimate of general production capability. It is not a ' . 'stock confirmation. Availability, lead time, final packaging and final logistics must be confirmed by our team.') => 'This tool produces a planning estimate of general production capability. Final capability, lead time, packaging and logistics must be confirmed by our team.',
      ('Planning estimate only — not a ' . 'stock confirmation.') => 'Planning estimate only — final capability and timing require confirmation.'
    );
    return isset($map[$text]) ? $map[$text] : $translated;
}, 10, 3 );

function nirvana_clear_public_caches() {
    delete_transient( 'nirvana_public_facets_v2' );
    delete_transient( 'nirvana_search_index_v2' );
}
add_action( 'save_post', function($post_id){ if(!wp_is_post_revision($post_id) && in_array(get_post_type($post_id),array('nirvana_tile','nirvana_variant','nirvana_size','nirvana_factory','post','page'),true)) nirvana_clear_public_caches(); } );
add_action( 'deleted_post', 'nirvana_clear_public_caches' );
add_action( 'set_object_terms', 'nirvana_clear_public_caches' );

function nirvana_search_index() {
    $cached=get_transient('nirvana_search_index_v2'); if(false!==$cached && is_array($cached)) return $cached;
    $ids=get_posts(array('post_type'=>array('nirvana_tile','post','page'),'post_status'=>'publish','fields'=>'ids','posts_per_page'=>250,'no_found_rows'=>true,'orderby'=>'modified','order'=>'DESC'));
    $index=array(); foreach($ids as $id){$type=get_post_type($id);$hay=get_the_title($id).' '.get_post_field('post_excerpt',$id).' '.wp_strip_all_tags(get_post_field('post_content',$id));if('nirvana_tile'===$type){$factory=absint(get_post_meta($id,'_nirvana_tile_factory_id',true));if($factory)$hay.=' '.get_the_title($factory);foreach(array('nirvana_body','nirvana_finish') as $tax){$names=wp_get_post_terms($id,$tax,array('fields'=>'names'));if(!is_wp_error($names))$hay.=' '.implode(' ',$names);}if(function_exists('nirvana_get_tile_variant_pairs'))foreach(nirvana_get_tile_variant_pairs($id,true) as $pair)$hay.=' '.($pair['size_label']??'').' '.($pair['thickness_label']??'');}$index[]=array('id'=>$id,'search'=>strtolower(remove_accents($hay)));}
    set_transient('nirvana_search_index_v2',$index,15*MINUTE_IN_SECONDS); return $index;
}
