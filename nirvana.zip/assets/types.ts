export type PageId = 'home' | 'about' | 'gallery' | 'blog' | 'contact';

export interface TileItem {
  id: string;
  name: string;
  category: 'Marble' | 'Porcelain' | 'Terrazzo' | 'Ceramic & Mosaic' | 'Large Format Slabs';
  origin: string;
  finish: 'Polished' | 'Honed' | 'Textured' | 'Matte';
  dimensions: string;
  thickness: string;
  description: string;
  colorHex: string;
  features: string[];
  recommendedUse: string;
}

export interface BlogPost {
  id: string;
  title: string;
  category: string;
  date: string;
  readTime: string;
  author: string;
  excerpt: string;
  content: string[];
  tags: string[];
}

export interface SearchResult {
  id: string;
  type: 'page' | 'tile' | 'blog';
  title: string;
  category: string;
  description: string;
  pageId: PageId;
}
