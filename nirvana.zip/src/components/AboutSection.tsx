import { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Truck, ChevronUp } from 'lucide-react';
import { PageId } from '../types';
import { TileData } from '../data/tileData';

interface Props {
  onSelectPage: (page: PageId) => void;
}

export default function AboutSection({ onSelectPage }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const handleScroll = () => {
      setShowScrollTop(el.scrollTop > 180);
    };
    el.addEventListener('scroll', handleScroll);
    return () => el.removeEventListener('scroll', handleScroll);
  }, []);

  const handleScrollToTop = () => {
    if (containerRef.current) {
      containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const loadingImages = [
    '/assets/Stock Images/download (1).png',
    '/assets/Stock Images/download (2).png',
    '/assets/Stock Images/download (4).png',
    '/assets/Stock Images/surreal-geometric-shapes-barren-desert_23-2151296312.jpg',
  ];

  const services = [
    {
      title: 'Quarry & Inventory Verification',
      desc: 'Physical auditing of factory stock in Spain, Italy, and Morocco prior to issuing supply contracts.',
    },
    {
      title: 'Short-Notice Freight Dispatch',
      desc: 'Rapid pallet containerization and expedited customs clearance to prevent site work stoppages.',
    },
    {
      title: 'Architectural Specification',
      desc: 'Technical consultation on slip ratings (R10/R11), frost proofing, and heavy commercial load specs.',
    },
    {
      title: 'Custom Sample Box Delivery',
      desc: 'Pre-cut sample boxes shipped directly to architectural offices worldwide within 24–48 hours.',
    },
  ];

  return (
    <div
      ref={containerRef}
      className="w-full h-full flex flex-col justify-between p-4 sm:p-6 md:p-8 max-w-5xl mx-auto overflow-y-auto max-h-[82vh] sm:max-h-[84vh] pb-32 sm:pb-36 custom-scrollbar pointer-events-auto select-text text-white relative"
    >
      {/* SECTION 1: CORE PHILOSOPHY & PURPOSE */}
      <section className="space-y-6 pb-8 border-b border-[#ead654]/30">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#ead654] animate-pulse" />
          <span className="text-[10px] sm:text-xs font-mono tracking-widest text-[#ead654] uppercase font-bold">
            NIRVANA ATELIER
          </span>
        </div>

        <h2 className="text-2xl sm:text-4xl md:text-5xl text-white font-bold leading-tight tracking-tight">
          Architectural Clarity & <span className="text-[#ead654]">Supply Certainty</span>
        </h2>

        <p className="text-neutral-200 text-xs sm:text-sm max-w-2xl font-normal leading-relaxed">
          We assist architectural practices, commercial developers, and stone specialists at the exact point in the supply chain where information accuracy converts risk into confidence.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 pt-2">
          <div className="bg-[#12232f]/90 border border-[#ead654]/30 rounded-2xl p-5 sm:p-6 relative overflow-hidden shadow-2xl backdrop-blur-md">
            <span className="text-3xl text-[#ead654] leading-none block mb-2 font-bold">“</span>
            <p className="text-lg sm:text-xl text-white font-semibold leading-snug">
              People don’t buy tiles; they buy <span className="text-[#ead654]">peace of mind</span> and certainty.
            </p>
            <p className="text-neutral-200 text-xs mt-3 leading-relaxed">
              In global commerce, missing inventory delays entire towers. We operate to eliminate gaps between specification and site delivery.
            </p>
          </div>

          <div className="bg-[#12232f]/90 border border-[#ead654]/30 rounded-2xl p-5 sm:p-6 relative overflow-hidden shadow-2xl backdrop-blur-md">
            <span className="text-3xl text-[#ead654] leading-none block mb-2 font-bold">“</span>
            <p className="text-lg sm:text-xl text-white font-semibold leading-snug">
              Tiles are the last thing installed, but <span className="text-[#ead654]">the first thing judged</span>.
            </p>
            <p className="text-neutral-200 text-xs mt-3 leading-relaxed">
              Steel and concrete hide behind drywall. What remains visible is the surface — seen, touched, and walked upon for decades.
            </p>
          </div>
        </div>
      </section>

      {/* SECTION 2: SUPPLY LOGISTICS & DISPATCH LOADINGS */}
      <section className="py-8 border-b border-[#ead654]/30 space-y-6">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#ead654]" />
          <span className="text-[10px] sm:text-xs font-mono tracking-widest text-[#ead654] uppercase font-bold">
            SERVICES & LOGISTICS
          </span>
        </div>

        <h3 className="text-xl sm:text-3xl md:text-4xl text-white font-bold">
          Supply Line Capabilities & Operations
        </h3>

        {/* Loading Pictures Gallery Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {loadingImages.map((img, idx) => (
            <div key={idx} className="relative h-28 sm:h-32 rounded-xl overflow-hidden border border-[#ead654]/30 bg-[#0c1922] group shadow-md">
              <img 
                src={img} 
                alt={`Loading dispatch ${idx + 1}`} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2">
                <span className="text-[9px] font-mono text-[#ead654] font-semibold">
                  Dispatch Lot #0{idx + 104}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Services List Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          {services.map((srv, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-[#12232f]/90 border border-[#ead654]/30 backdrop-blur-md flex items-start gap-3 shadow-lg">
              <div className="p-2 rounded-lg bg-[#0c1922] text-[#ead654] shrink-0 border border-[#ead654]/40">
                <Truck size={16} />
              </div>
              <div>
                <h4 className="text-sm sm:text-base text-white font-semibold">{srv.title}</h4>
                <p className="text-xs text-neutral-200 font-normal leading-relaxed mt-1">{srv.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SECTION 3: NETWORK & PERFORMANCE METRICS */}
      <section className="py-8 border-b border-[#ead654]/30 space-y-6">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#ead654]" />
          <span className="text-[10px] sm:text-xs font-mono tracking-widest text-[#ead654] uppercase font-bold">
            NETWORK & METRICS
          </span>
        </div>

        <h3 className="text-xl sm:text-3xl md:text-4xl text-white font-bold">
          Global Network & Statistics
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
          <div className="p-5 rounded-2xl bg-[#12232f]/90 border border-[#ead654]/30 backdrop-blur-md space-y-2 shadow-lg">
            <h4 className="text-base sm:text-lg text-[#ead654] font-bold">Architectural Practices</h4>
            <p className="text-xs text-neutral-200 leading-relaxed">
              Partnering with practices across Yazd, Tehran, Milan, Dubai, and London to specify certified stone slabs.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#12232f]/90 border border-[#ead654]/30 backdrop-blur-md space-y-2 shadow-lg">
            <h4 className="text-base sm:text-lg text-[#ead654] font-bold">Commercial Developers</h4>
            <p className="text-xs text-neutral-200 leading-relaxed">
              Supplying high-density porcelain and marble for luxury hotels, high-end residential towers, and boutique retail flagships.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#12232f]/90 border border-[#ead654]/30 backdrop-blur-md space-y-2 shadow-lg">
            <h4 className="text-base sm:text-lg text-[#ead654] font-bold">European Quarries</h4>
            <p className="text-xs text-neutral-200 leading-relaxed">
              Direct contracts with quarry masters in Carrara, Modena, Castellón, and Fez ensuring verified stock.
            </p>
          </div>
        </div>

        {/* Statistics Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 pt-2">
          {TileData.statistics.map((stat) => (
            <motion.div
              key={stat.id}
              whileHover={{ y: -3 }}
              className="p-4 rounded-2xl bg-[#12232f]/90 border border-[#ead654]/30 backdrop-blur-md flex flex-col justify-between shadow-lg"
            >
              <div>
                <span className="text-2xl sm:text-3xl text-[#ead654] font-extrabold block">
                  {stat.value}
                </span>
                <span className="text-xs font-bold text-white block mt-1">
                  {stat.label}
                </span>
              </div>
              <p className="text-[11px] text-neutral-300 leading-snug mt-2">
                {stat.subtext}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* SECTION 4: GET IN TOUCH BUTTON */}
      <section className="pt-8 pb-4 flex flex-col items-center text-center space-y-4">
        <span className="text-xs font-mono text-[#ead654] uppercase tracking-widest font-bold">
          Ready to collaborate
        </span>
        <h3 className="text-xl sm:text-3xl md:text-4xl text-white max-w-xl font-bold">
          Let’s discuss your upcoming tile & stone specifications
        </h3>
        
        <button
          onClick={() => onSelectPage('contact')}
          className="mt-2 h-11 sm:h-12 px-7 sm:px-8 rounded-full bg-[#ead654] text-[#183242] font-bold text-xs uppercase tracking-wider hover:bg-[#f3e371] hover:scale-105 transition-all shadow-xl shadow-[#ead654]/20 cursor-pointer flex items-center gap-2"
        >
          <span>Get In Touch</span>
          <ArrowRight size={16} />
        </button>
      </section>

      {/* FLOATING SCROLL TO TOP BUTTON */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={handleScrollToTop}
            className="fixed bottom-14 sm:bottom-16 right-4 sm:right-8 z-40 p-3 rounded-full bg-[#183242] border-2 border-[#ead654] text-[#ead654] hover:bg-[#ead654] hover:text-[#183242] shadow-2xl transition-all cursor-pointer flex items-center justify-center group active:scale-95"
            title="Scroll to Top"
            aria-label="Scroll to Top"
          >
            <ChevronUp size={20} className="group-hover:-translate-y-0.5 transition-transform" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}

