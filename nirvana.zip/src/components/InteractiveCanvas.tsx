import { useEffect, useRef } from 'react';

interface Props {
  scrollProgress: number; // 0 to 3 corresponding to sections
}

export default function InteractiveCanvas({ scrollProgress }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  
  // Track mouse coordinates for subtle parallax
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.targetX = (e.clientX / window.innerWidth) * 2 - 1;
      mouseRef.current.targetY = (e.clientY / window.innerHeight) * 2 - 1;
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = canvas.width;
    let height = canvas.height;

    const resizeObserver = new ResizeObserver((entries) => {
      for (let entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        width = w;
        height = h;
        canvas.width = w * window.devicePixelRatio;
        canvas.height = h * window.devicePixelRatio;
        ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      }
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    // Procedural entities
    const daisyCount = 140;
    const daisies: Array<{ x: number; y: number; scale: number; swaySpeed: number; swayOffset: number }> = [];
    for (let i = 0; i < daisyCount; i++) {
      daisies.push({
        x: Math.random(),
        y: 0.3 + Math.random() * 0.7,
        scale: 0.4 + Math.random() * 0.7,
        swaySpeed: 0.5 + Math.random() * 1.5,
        swayOffset: Math.random() * Math.PI * 2,
      });
    }

    const generateMoonCraters = (seed: number) => {
      const craters: Array<{ x: number; y: number; r: number; opacity: number }> = [];
      let lcg = seed;
      const random = () => {
        lcg = (lcg * 1664525 + 1013904223) % 4294967296;
        return lcg / 4294967296;
      };
      
      for (let i = 0; i < 15; i++) {
        const angle = random() * Math.PI * 2;
        const dist = Math.sqrt(random()) * 0.8;
        craters.push({
          x: Math.cos(angle) * dist,
          y: Math.sin(angle) * dist,
          r: 0.05 + random() * 0.15,
          opacity: 0.05 + random() * 0.12,
        });
      }
      return craters;
    };

    const moon1Craters = generateMoonCraters(42);
    const moon2Craters = generateMoonCraters(1337);

    let currentScroll = scrollProgress;
    let time = 0;

    const render = () => {
      time += 0.008;

      currentScroll += (scrollProgress - currentScroll) * 0.06;
      
      const mouse = mouseRef.current;
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      let camX = mouse.x * 20;
      let camY = mouse.y * 10;
      let zoom = 1.0;

      if (currentScroll <= 1) {
        const t = currentScroll;
        camX += t * -100;
        camY += t * -40;
        zoom = 1.0 + t * 0.15;
      } else if (currentScroll <= 2) {
        const t = currentScroll - 1;
        camX += -100 + t * 60;
        camY += -40 + t * -120;
        zoom = 1.15 - t * 0.1;
      } else {
        const t = currentScroll - 2;
        camX += -40 + t * 40;
        camY += -160 + t * -150;
        zoom = 1.05 + t * 0.05;
      }

      ctx.clearRect(0, 0, width, height);

      // 1. BACKGROUND SKY GRADIENT USING DARK BLUE (#183242) & DEEP OCEAN SLATE (#0b161f)
      const skyGrad = ctx.createLinearGradient(0, 0, 0, height);
      
      if (currentScroll < 1) {
        skyGrad.addColorStop(0, '#060d13');
        skyGrad.addColorStop(0.5, '#0b1924');
        skyGrad.addColorStop(1, '#183242');
      } else if (currentScroll < 2) {
        skyGrad.addColorStop(0, '#04090d');
        skyGrad.addColorStop(0.4, '#0d1f2a');
        skyGrad.addColorStop(1, '#1f3e52');
      } else if (currentScroll < 3) {
        skyGrad.addColorStop(0, '#020508');
        skyGrad.addColorStop(0.6, '#08141d');
        skyGrad.addColorStop(1, '#132835');
      } else {
        skyGrad.addColorStop(0, '#020406');
        skyGrad.addColorStop(1, '#0b161f');
      }
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, width, height);

      // Add gentle golden-yellow particles (#ead654)
      if (currentScroll > 0.5) {
        const starAlpha = Math.min(currentScroll * 0.5, 0.7);
        ctx.fillStyle = `rgba(234, 214, 84, ${starAlpha})`;
        for (let j = 0; j < 50; j++) {
          const sx = ((j * 193) % width) + camX * 0.4;
          const sy = ((j * 431) % (height * 0.6)) + camY * 0.4;
          ctx.beginPath();
          ctx.arc(sx, sy, (j % 3 === 0) ? 1.4 : 0.8, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      ctx.save();
      ctx.translate(width / 2, height / 2);
      ctx.scale(zoom, zoom);
      ctx.translate(-width / 2, -height / 2);

      ctx.translate(camX, camY);

      // 2. RENDER THE LUNAR GOLD SPHERES
      let m1X = width * 0.41 + (currentScroll * 25);
      let m1Y = height * 0.38 + (currentScroll * -20);
      let m1R = Math.min(width * 0.12, 110);

      let m2X = width * 0.58 + (currentScroll * -15);
      let m2Y = height * 0.26 + (currentScroll * -45);
      let m2R = Math.min(width * 0.09, 85);

      if (currentScroll > 1.0) {
        const t = currentScroll - 1.0;
        m1Y += t * 80;
        m2Y += t * 140;
        m1X -= t * 30;
        m2X += t * 50;
      }

      const drawMoon = (x: number, y: number, r: number, craters: typeof moon1Craters, glowPower: number) => {
        // Yellow Ambient Glow (#ead654)
        const glowSteps = 4;
        for (let j = glowSteps; j > 0; j--) {
          const glowR = r * (1 + j * 0.7);
          const bloom = ctx.createRadialGradient(x, y, r * 0.8, x, y, glowR);
          bloom.addColorStop(0, `rgba(234, 214, 84, ${0.22 / j * glowPower})`);
          bloom.addColorStop(0.4, `rgba(234, 214, 84, ${0.09 / j * glowPower})`);
          bloom.addColorStop(1, 'rgba(234, 214, 84, 0)');
          ctx.fillStyle = bloom;
          ctx.beginPath();
          ctx.arc(x, y, glowR, 0, Math.PI * 2);
          ctx.fill();
        }

        // Base sphere surface in warm gold/yellow
        const moonGrad = ctx.createRadialGradient(
          x - r * 0.3, y - r * 0.3, r * 0.1, 
          x, y, r
        );
        moonGrad.addColorStop(0, '#ffffff');
        moonGrad.addColorStop(0.35, '#f7ea8d');
        moonGrad.addColorStop(0.8, '#ead654');
        moonGrad.addColorStop(1, '#a89423');
        
        ctx.fillStyle = moonGrad;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();

        ctx.save();
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.clip();

        craters.forEach(crater => {
          const cx = x + crater.x * r;
          const cy = y + crater.y * r;
          const cr = crater.r * r;

          const craterGrad = ctx.createRadialGradient(
            cx + cr * 0.2, cy + cr * 0.2, 0,
            cx, cy, cr
          );
          craterGrad.addColorStop(0, `rgba(120, 102, 23, ${crater.opacity * 2.5})`);
          craterGrad.addColorStop(0.7, `rgba(168, 148, 35, ${crater.opacity})`);
          craterGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');

          ctx.fillStyle = craterGrad;
          ctx.beginPath();
          ctx.arc(cx, cy, cr, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = `rgba(255, 255, 255, ${crater.opacity * 0.5})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(cx, cy, cr, Math.PI * 0.75, Math.PI * 1.75);
          ctx.stroke();
        });

        ctx.restore();
      };

      const moonOpacity = currentScroll >= 2.0 ? Math.max(1 - (currentScroll - 2.0), 0.25) : 1.0;
      
      drawMoon(m1X, m1Y, m1R, moon1Craters, moonOpacity);
      drawMoon(m2X, m2Y, m2R, moon2Craters, moonOpacity * 0.85);

      // 3. RENDER THREE LAYERS OF HILLS IN DARK BLUE & SLATE (#183242)
      const drawHill = (
        baseY: number, 
        amplitude: number, 
        frequency: number, 
        colorStart: string, 
        colorEnd: string, 
        grassStrength: number,
        layerIndex: number
      ) => {
        ctx.beginPath();
        ctx.moveTo(0, height);

        const curvePoints: Array<{ x: number; y: number }> = [];
        const step = 15;
        const scrollOffset = currentScroll * (layerIndex * -35);

        for (let lx = 0; lx <= width + step; lx += step) {
          const angle = (lx + scrollOffset) * frequency;
          const ly = baseY + Math.sin(angle) * amplitude + Math.cos(angle * 0.5) * (amplitude * 0.4);
          ctx.lineTo(lx, ly);
          curvePoints.push({ x: lx, y: ly });
        }

        ctx.lineTo(width, height);
        ctx.closePath();

        const hillGrad = ctx.createLinearGradient(0, baseY - amplitude, 0, height);
        hillGrad.addColorStop(0, colorStart);
        hillGrad.addColorStop(0.4, colorEnd);
        hillGrad.addColorStop(1, '#050a0e');
        
        ctx.fillStyle = hillGrad;
        ctx.fill();

        // Rim highlight in Brand Yellow (#ead654)
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(curvePoints[0].x, curvePoints[0].y);
        for (let p = 1; p < curvePoints.length; p++) {
          ctx.lineTo(curvePoints[p].x, curvePoints[p].y);
        }
        ctx.lineTo(width, height);
        ctx.lineTo(0, height);
        ctx.clip();

        curvePoints.forEach((pt, pIdx) => {
          if (pIdx % 3 !== 0) return;
          
          const d1 = Math.hypot(pt.x - m1X, pt.y - m1Y);
          const d2 = Math.hypot(pt.x - m2X, pt.y - m2Y);
          
          const limit = width * 0.35;
          const glowIntensity = Math.max(0, 1 - d1 / limit) * 0.7 + Math.max(0, 1 - d2 / limit) * 0.5;

          if (glowIntensity > 0) {
            ctx.fillStyle = `rgba(234, 214, 84, ${glowIntensity * 0.18 * moonOpacity})`;
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, 40, 0, Math.PI * 2);
            ctx.fill();
          }
        });

        if (grassStrength > 0) {
          ctx.strokeStyle = colorStart;
          ctx.lineWidth = 1;
          for (let pIdx = 0; pIdx < curvePoints.length; pIdx += 2) {
            const pt = curvePoints[pIdx];
            
            const grassCount = Math.floor(2 + (pt.x % 3));
            for (let g = 0; g < grassCount; g++) {
              const grassHeight = (12 + (pt.y % 15)) * grassStrength;
              const sway = Math.sin(time * 1.5 + pt.x * 0.05) * 3;
              
              ctx.beginPath();
              ctx.moveTo(pt.x + g * 2, pt.y + 1);
              ctx.quadraticCurveTo(
                pt.x + g * 2 + sway * 0.5, 
                pt.y - grassHeight * 0.5,
                pt.x + g * 2 + sway, 
                pt.y - grassHeight
              );
              ctx.stroke();
            }
          }
        }
        ctx.restore();
      };

      // Layer 1: Distant Background Hill (Navy #183242)
      drawHill(
        height * 0.55, 
        width * 0.035, 
        0.002, 
        '#183242', 
        '#0f222e', 
        0.0,
        1
      );

      // Layer 2: Midground Main Hill (Rich dark slate blue)
      drawHill(
        height * 0.64, 
        width * 0.045, 
        0.0035, 
        '#1c3c50', 
        '#112532', 
        0.6,
        2
      );

      // Daisies with yellow centers (#ead654)
      daisies.forEach(daisy => {
        const dx = daisy.x * width + camX * 0.25 * (1 + daisy.y);
        const dy = height * 0.6 + daisy.y * (height * 0.4) + camY * 0.15;

        const sway = Math.sin(time * daisy.swaySpeed + daisy.swayOffset) * 2 * daisy.scale;
        const size = 3 * daisy.scale;

        const d1 = Math.hypot(dx - m1X, dy - m1Y);
        const lightFac = Math.max(0.1, Math.min(1.0, 1 - d1 / (width * 0.35)));

        ctx.save();
        ctx.translate(dx, dy);
        
        ctx.fillStyle = `rgba(255, 255, 255, ${0.75 * lightFac * moonOpacity})`;
        for (let p = 0; p < 6; p++) {
          const angle = (p * Math.PI) / 3 + sway * 0.15;
          ctx.beginPath();
          ctx.arc(Math.cos(angle) * size, Math.sin(angle) * size, size * 0.6, 0, Math.PI * 2);
          ctx.fill();
        }
        
        ctx.fillStyle = `rgba(234, 214, 84, ${0.95 * lightFac * moonOpacity})`;
        ctx.beginPath();
        ctx.arc(0 + sway * 0.05, 0 + sway * 0.05, size * 0.45, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      });

      // Layer 3: Foreground Slope
      drawHill(
        height * 0.78, 
        width * 0.06, 
        0.0018, 
        '#0c1922', 
        '#060c11', 
        1.2,
        3
      );

      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
    };
  }, [scrollProgress]);

  return (
    <div 
      ref={containerRef}
      className="absolute inset-0 w-full h-full z-0 overflow-hidden select-none pointer-events-none"
    >
      <canvas 
        ref={canvasRef}
        className="block w-full h-full"
      />
    </div>
  );
}
