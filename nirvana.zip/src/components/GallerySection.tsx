import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Filter, Eye, Check, X, Sparkles, Image as ImageIcon, Calculator, Layers, Plus, CheckSquare, Square, ChevronDown, ChevronUp } from 'lucide-react';
import { TileItem, TileBody, GlazeFinish } from '../types';
import { TileData } from '../data/tileData';

interface Props {
  onRequestSampleModal: (tileName: string) => void;
  onModalToggle?: (isOpen: boolean) => void;
  onOpenCalculator?: (tileName?: string) => void;
  targetTileId?: string | null;
}

export default function GallerySection({
  onRequestSampleModal,
  onModalToggle,
  onOpenCalculator,
  targetTileId,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [showScrollTop, setShowScrollTop] = useState<boolean>(false);

  // Filter States
  const [selectedSize, setSelectedSize] = useState<string>('All Sizes');
  const [selectedBody, setSelectedBody] = useState<string>('All Bodies');
  const [selectedFinish, setSelectedFinish] = useState<string>('All Finishes');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState<boolean>(false);

  // Pagination State
  const [visibleCount, setVisibleCount] = useState<number>(9);

  // Multi-select state for sample box requests
  const [selectedSampleTileIds, setSelectedSampleTileIds] = useState<string[]>([]);

  // Modal State
  const [selectedTile, setSelectedTile] = useState<TileItem | null>(null);
  const [activeImageIndex, setActiveImageIndex] = useState<number>(0);

  // Filter Categories
  const sizeOptions = ['All Sizes', '30×60 cm', '60×60 cm'];
  const bodyOptions: ('All Bodies' | TileBody)[] = ['All Bodies', 'Red Body', 'White Body'];
  const finishOptions: ('All Finishes' | GlazeFinish)[] = ['All Finishes', 'Matte', 'Glazed'];

  // Scroll to top listener
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const handleScroll = () => {
      setShowScrollTop(el.scrollTop > 180);
    };
    el.addEventListener('scroll', handleScroll);
    return () => el.removeEventListener('scroll', handleScroll);
  }, []);

  const handleScrollToTop = () => {
    if (containerRef.current) {
      containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleOpenModal = (tile: TileItem | null) => {
    setSelectedTile(tile);
    setActiveImageIndex(0);
    if (onModalToggle) {
      onModalToggle(!!tile);
    }
  };

  // Support targeted tile from search
  useEffect(() => {
    if (targetTileId) {
      const tile = TileData.tiles.find((t) => t.id === targetTileId);
      if (tile) {
        handleOpenModal(tile);
      }
    }
  }, [targetTileId]);

  // Handle Body Change
  const handleBodyChange = (body: string) => {
    setSelectedBody(body);
    setVisibleCount(9);
  };

  // Filtered Tiles Logic
  const filteredTiles = useMemo(() => {
    return TileData.tiles.filter((tile) => {
      // 1. Size Filter
      if (selectedSize !== 'All Sizes' && tile.sizeCategory !== selectedSize) {
        return false;
      }
      // 2. Body Filter
      if (selectedBody !== 'All Bodies' && tile.body !== selectedBody) {
        return false;
      }
      // 3. Finish Filter
      if (selectedFinish !== 'All Finishes' && tile.glazeFinish !== selectedFinish) {
        return false;
      }
      return true;
    });
  }, [selectedSize, selectedBody, selectedFinish]);

  // Displayed Tiles according to pagination limit
  const displayedTiles = useMemo(() => {
    return filteredTiles.slice(0, visibleCount);
  }, [filteredTiles, visibleCount]);

  const velvetTile = TileData.tiles.find((t) => t.id === 'velvet-porcelain-60x60') || TileData.tiles[0];

  // Multi-select toggle for sample box
  const toggleSampleSelection = (tileId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedSampleTileIds((prev) =>
      prev.includes(tileId) ? prev.filter((id) => id !== tileId) : [...prev, tileId]
    );
  };

  // Selected tile objects for sample request
  const selectedSampleTiles = useMemo(() => {
    return TileData.tiles.filter((t) => selectedSampleTileIds.includes(t.id));
  }, [selectedSampleTileIds]);

  // Bulk Request Sample Box Handler
  const handleBulkSampleRequest = () => {
    if (selectedSampleTiles.length === 0) return;
    const names = selectedSampleTiles.map((t) => t.name).join(', ');
    onRequestSampleModal(`Bulk Sample Request (${selectedSampleTiles.length} items): ${names}`);
  };

  return (
    <div
      ref={containerRef}
      className="w-full h-full flex flex-col justify-between p-4 sm:p-6 md:p-10 max-w-6xl mx-auto overflow-y-auto max-h-[82vh] sm:max-h-[84vh] pb-36 sm:pb-40 custom-scrollbar pointer-events-auto select-text text-white relative"
    >
      
      {/* Page Header */}
      <div>
        <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#ead654] animate-pulse" />
            <span className="text-[10px] font-mono tracking-widest text-[#ead654] uppercase font-bold">
              CURATED GALLERY / ARCHITECTURAL TILES
            </span>
          </div>
          {onOpenCalculator && (
            <button
              onClick={() => onOpenCalculator()}
              className="px-3 py-1.5 rounded-xl bg-[#0c1922] border border-[#ead654]/40 hover:border-[#ead654] text-[#ead654] hover:text-white text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer shadow-md active:scale-95"
            >
              <Calculator size={14} />
              <span>Project Tile Calculator</span>
            </button>
          )}
        </div>

        <h2 className="text-2xl sm:text-4xl md:text-5xl text-white font-bold tracking-tight">
          Velvet Porcelain & Architectural Collections
        </h2>
        <p className="text-neutral-200 text-xs sm:text-sm mt-2 max-w-2xl font-normal leading-relaxed">
          Filter by tile dimensions, material body matrix, and glaze finishes. Select multiple products to build your custom architectural sample box.
        </p>

        {/* COMPREHENSIVE MULTI-LEVEL FILTER CONTROLS */}
        <div className="mt-4 sm:mt-6 bg-[#0c1922]/90 border border-[#ead654]/30 rounded-2xl p-3 sm:p-4 shadow-xl space-y-3">
          
          {/* Mobile Filter Toggle Header */}
          <div className="flex sm:hidden items-center justify-between">
            <button
              onClick={() => setIsMobileFilterOpen((prev) => !prev)}
              className="w-full flex items-center justify-between text-xs font-bold text-[#ead654] py-1 cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Filter size={14} />
                <span>Filter Collections {(selectedSize !== 'All Sizes' || selectedBody !== 'All Bodies' || selectedFinish !== 'All Finishes') ? '(Active Filters)' : ''}</span>
              </span>
              <div className="flex items-center gap-1 text-neutral-300">
                <span className="text-[10px] font-mono uppercase">{isMobileFilterOpen ? 'Hide' : 'Show Filters'}</span>
                {isMobileFilterOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              </div>
            </button>
          </div>

          {/* Filter Body - Always shown on desktop, collapsible on mobile */}
          <div className={`${isMobileFilterOpen ? 'block' : 'hidden'} sm:block space-y-3 pt-2 sm:pt-0`}>
            {/* 1. Size Filter Row */}
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 pb-1">
              <span className="text-[10px] font-mono text-[#ead654] uppercase mr-1 flex items-center gap-1 font-bold shrink-0">
                <Filter size={11} /> Size:
              </span>
              {sizeOptions.map((sz) => (
                <button
                  key={sz}
                  onClick={() => {
                    setSelectedSize(sz);
                    setVisibleCount(9);
                  }}
                  className={`px-3 py-1.5 rounded-full text-xs font-sans transition-all cursor-pointer ${
                    selectedSize === sz
                      ? 'bg-[#ead654] text-[#183242] font-extrabold shadow-md'
                      : 'bg-[#183242]/90 border border-[#ead654]/25 text-neutral-300 hover:text-white hover:border-[#ead654]/60'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>

            {/* 2. Body & Sub-Finish Filter Rows */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[#ead654]/20">
              {/* Body Selector */}
              <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 pb-1">
                <span className="text-[10px] font-mono text-[#ead654] uppercase mr-1 font-bold shrink-0">
                  Body:
                </span>
                {bodyOptions.map((b) => (
                  <button
                    key={b}
                    onClick={() => handleBodyChange(b)}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-sans transition-all cursor-pointer ${
                      selectedBody === b
                        ? 'bg-[#ead654] text-[#183242] font-bold'
                        : 'bg-[#183242] border border-[#ead654]/20 text-neutral-300 hover:text-white'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>

              {/* Sub-Finish Selector (Super Glazed, Glazed, Unglazed) */}
              <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 pb-1">
                <span className="text-[10px] font-mono text-[#ead654] uppercase mr-1 font-bold shrink-0">
                  Finish:
                </span>
                {finishOptions.map((f) => (
                  <button
                    key={f}
                    onClick={() => {
                      setSelectedFinish(f);
                      setVisibleCount(9);
                    }}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-sans transition-all cursor-pointer ${
                      selectedFinish === f
                        ? 'bg-[#ead654] text-[#183242] font-bold'
                        : 'bg-[#183242] border border-[#ead654]/20 text-neutral-300 hover:text-white'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* FLAGSHIP FEATURED PRODUCT BANNER: VELVET 60X60 PORCELAIN */}
      {(selectedSize === 'All Sizes' || selectedSize === '60×60 cm') &&
      (selectedBody === 'All Bodies' || selectedBody === 'Porcelain') &&
      (selectedFinish === 'All Finishes' || selectedFinish === 'Super Glazed') ? (
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={() => handleOpenModal(velvetTile)}
          className="my-6 bg-gradient-to-r from-[#183242] via-[#0c1922] to-[#183242] border-2 border-[#ead654]/60 rounded-3xl p-5 md:p-7 shadow-2xl relative overflow-hidden group cursor-pointer"
        >
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#ead654]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center relative z-10">
            {/* Left: Product Info */}
            <div className="lg:col-span-7 space-y-3">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-[#ead654] text-[#183242] text-[10px] font-mono uppercase font-bold tracking-wider">
                  Flagship Product
                </span>
                <span className="text-[10px] font-mono text-[#ead654] uppercase tracking-widest font-semibold">
                  60 × 60 cm Porcelain • Super Glazed
                </span>
              </div>

              <h3 className="font-serif text-2xl md:text-4xl text-white font-normal group-hover:text-[#ead654] transition-colors">
                Velvet Porcelain 60×60
              </h3>

              <p className="text-xs md:text-sm text-neutral-300 font-light leading-relaxed">
                Silky micro-honed finish engineered specifically for <span className="text-[#ead654] font-medium">bathrooms, wet rooms, and high-performance kitchens</span>. Features R10 slip-safety and non-porous stain resistance.
              </p>

              <div className="flex flex-wrap gap-2 pt-1">
                {velvetTile.features.map((f, i) => (
                  <span key={i} className="text-[10px] font-mono px-2.5 py-1 rounded-md bg-[#0c1922] border border-[#ead654]/30 text-neutral-200 flex items-center gap-1">
                    <Check size={11} className="text-[#ead654]" />
                    {f}
                  </span>
                ))}
              </div>

              <div className="pt-3 flex flex-wrap items-center gap-3">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onRequestSampleModal('Velvet Porcelain 60×60');
                  }}
                  className="px-4 py-2.5 rounded-xl bg-[#ead654] text-[#183242] font-bold text-xs uppercase tracking-wider hover:bg-[#f3e371] active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-[#ead654]/20"
                >
                  <Sparkles size={15} />
                  <span>Request Sample Box</span>
                </button>

                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleOpenModal(velvetTile);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-[#0c1922] border border-[#ead654]/40 hover:border-[#ead654] text-[#ead654] hover:text-white font-semibold text-xs transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95"
                >
                  <Eye size={15} />
                  <span>View Specs & Renders</span>
                </button>
              </div>
            </div>

            {/* Right: Image Preview */}
            <div className="lg:col-span-5 flex gap-3 overflow-hidden rounded-2xl border border-[#ead654]/40 bg-[#0c1922] p-2">
              <div className="w-1/2 h-44 rounded-xl overflow-hidden relative group-hover:scale-102 transition-transform">
                <img 
                  src="/assets/Gallery/Velvet/Velvet Render.png" 
                  alt="Velvet Render" 
                  className="w-full h-full object-cover object-center"
                />
                <div className="absolute bottom-1.5 left-1.5 bg-black/70 px-2 py-0.5 rounded text-[9px] font-mono text-[#ead654]">
                  Render
                </div>
              </div>
              <div className="w-1/2 h-44 rounded-xl overflow-hidden relative group-hover:scale-102 transition-transform">
                <img 
                  src="/assets/Gallery/Velvet/Velvet Tex.png" 
                  alt="Velvet Texture" 
                  className="w-full h-full object-cover object-center"
                />
                <div className="absolute bottom-1.5 left-1.5 bg-black/70 px-2 py-0.5 rounded text-[9px] font-mono text-[#ead654]">
                  Texture
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      ) : null}

      {/* Grid of Tile Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 my-4">
        {displayedTiles.map((tile) => {
          const isSelectedForSample = selectedSampleTileIds.includes(tile.id);
          return (
            <motion.div
              key={tile.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className={`group relative bg-[#183242]/70 border rounded-2xl p-4 transition-all duration-300 flex flex-col justify-between cursor-pointer ${
                isSelectedForSample
                  ? 'border-[#ead654] bg-[#183242] shadow-lg shadow-[#ead654]/10'
                  : 'border-[#ead654]/25 hover:border-[#ead654]'
              }`}
              onClick={() => handleOpenModal(tile)}
            >
              {/* Top Select Checkbox Toggle */}
              <div className="absolute top-3 left-3 z-20">
                <button
                  onClick={(e) => toggleSampleSelection(tile.id, e)}
                  className={`px-2 py-1 rounded-lg text-[10px] font-mono font-bold flex items-center gap-1.5 backdrop-blur-md transition-all cursor-pointer ${
                    isSelectedForSample
                      ? 'bg-[#ead654] text-[#183242] shadow-md'
                      : 'bg-black/70 border border-[#ead654]/40 text-[#ead654] hover:bg-black'
                  }`}
                  title="Select for Sample Box Request"
                >
                  {isSelectedForSample ? (
                    <>
                      <CheckSquare size={13} />
                      <span>Sample Added</span>
                    </>
                  ) : (
                    <>
                      <Square size={13} />
                      <span>+ Add Sample</span>
                    </>
                  )}
                </button>
              </div>

              {/* Swatch / Preview Image */}
              <div className="w-full h-40 rounded-xl relative overflow-hidden flex items-center justify-center mb-3 border border-white/10 bg-[#0c1922]">
                {tile.images && tile.images.length > 0 ? (
                  <img 
                    src={tile.images[0]} 
                    alt={tile.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                ) : (
                  <div 
                    className="w-full h-full flex items-center justify-center"
                    style={{ background: `radial-gradient(circle, ${tile.colorHex} 0%, #0c1922 100%)` }}
                  >
                    <span className="font-serif italic text-white/50 text-base">{tile.name}</span>
                  </div>
                )}

                <div className="absolute bottom-2.5 right-2.5 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-md text-[9px] font-mono text-[#ead654] border border-[#ead654]/30">
                  {tile.dimensions}
                </div>
              </div>

              {/* Info Body */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-start text-[10px] font-mono">
                  <span className="text-[#ead654] uppercase tracking-widest font-bold">
                    {tile.body} • {tile.glazeFinish}
                  </span>
                  <span className="text-neutral-400">
                    {tile.origin}
                  </span>
                </div>

                <h3 className="font-serif text-lg text-white font-normal group-hover:text-[#ead654] transition-colors">
                  {tile.name}
                </h3>

                <p className="text-xs text-neutral-300 line-clamp-2 font-light leading-relaxed">
                  {tile.description}
                </p>

                <div className="pt-2 flex justify-between items-center text-[10px] font-mono text-neutral-400 border-t border-[#ead654]/15 mt-3">
                  <span>Finish: {tile.glazeFinish}</span>
                  <span className="group-hover:text-[#ead654] transition-colors flex items-center gap-1 font-sans text-xs text-neutral-200">
                    View Specs <Eye size={12} />
                  </span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* LOAD MORE BUTTON IF ITEMS REMAIN */}
      {filteredTiles.length > visibleCount && (
        <div className="flex justify-center my-6">
          <button
            onClick={() => setVisibleCount((prev) => prev + 9)}
            className="px-6 py-3 rounded-2xl bg-[#0c1922] border-2 border-[#ead654]/50 hover:border-[#ead654] text-[#ead654] hover:text-white font-sans text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-lg flex items-center gap-2 active:scale-95"
          >
            <span>Load More Products</span>
            <ChevronDown size={16} />
          </button>
        </div>
      )}

      {/* FLOATING MULTI-SELECT SAMPLE BOX REQUEST BAR */}
      <AnimatePresence>
        {selectedSampleTiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-24 sm:bottom-8 left-1/2 -translate-x-1/2 z-40 bg-[#183242] border-2 border-[#ead654] rounded-2xl p-2 sm:p-3.5 shadow-2xl max-w-lg w-[88%] sm:w-[92%] flex flex-col sm:flex-row items-center justify-between gap-2 text-white backdrop-blur-md"
          >
            <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto">
              <div className="w-7 h-7 rounded-lg bg-[#ead654] text-[#183242] font-mono font-extrabold flex items-center justify-center shrink-0 text-xs">
                {selectedSampleTiles.length}
              </div>
              <div className="min-w-0">
                <span className="text-[9px] font-mono text-[#ead654] uppercase font-bold block">
                  Sample Box Selection
                </span>
                <p className="text-[11px] sm:text-xs text-neutral-200 line-clamp-1 font-medium">
                  {selectedSampleTiles.map((t) => t.name).join(', ')}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 justify-end">
              <button
                onClick={() => setSelectedSampleTileIds([])}
                className="px-2 py-1 rounded-lg text-neutral-400 hover:text-white text-[10px] sm:text-xs transition-colors"
                title="Clear Selection"
              >
                Clear
              </button>

              <button
                onClick={handleBulkSampleRequest}
                className="px-3.5 py-1.5 bg-[#ead654] hover:bg-[#f3e371] text-[#183242] font-sans text-[11px] sm:text-xs font-extrabold uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer flex items-center gap-1.5 active:scale-95"
              >
                <Sparkles size={14} />
                <span>Request Sample Box ({selectedSampleTiles.length})</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* SINGLE TILE SPECIFICATIONS MODAL */}
      <AnimatePresence>
        {selectedTile && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3.5 sm:p-5 select-none">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => handleOpenModal(null)}
              className="absolute inset-0 bg-black/85 backdrop-blur-md cursor-pointer"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 15 }}
              className="relative w-[92%] sm:w-full max-w-2xl bg-[#183242] border border-[#ead654]/40 rounded-2xl sm:rounded-3xl text-white shadow-2xl z-10 overflow-hidden max-h-[82vh] sm:max-h-[85vh] flex flex-col my-auto"
            >
              {/* Modal Header */}
              <div className="p-4 sm:p-5 border-b border-[#ead654]/20 flex justify-between items-start shrink-0 bg-[#183242]">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-mono tracking-widest text-[#ead654] uppercase font-bold">
                      {selectedTile.body} • {selectedTile.glazeFinish} Finish
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl md:text-3xl text-white font-bold tracking-tight">
                    {selectedTile.name}
                  </h3>
                </div>
                <button
                  onClick={() => handleOpenModal(null)}
                  className="w-8 h-8 rounded-full bg-black/40 hover:bg-black/70 text-neutral-300 hover:text-white flex items-center justify-center transition-all cursor-pointer shrink-0 ml-2 border border-[#ead654]/30"
                  aria-label="Close modal"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Scrollable Modal Body */}
              <div className="p-4 sm:p-6 overflow-y-auto custom-scrollbar grow space-y-4 select-text">
                {/* Product Picture Display */}
                <div className="bg-[#0c1922] rounded-2xl border border-[#ead654]/30 p-2 overflow-hidden">
                  <div className="w-full h-48 sm:h-60 md:h-64 rounded-xl overflow-hidden relative bg-black/40 flex items-center justify-center">
                    {selectedTile.images && selectedTile.images.length > 0 ? (
                      <img 
                        src={selectedTile.images[activeImageIndex] || selectedTile.images[0]} 
                        alt={`${selectedTile.name} view ${activeImageIndex + 1}`} 
                        className="w-full h-full object-contain max-h-64"
                      />
                    ) : (
                      <div 
                        className="w-full h-full flex items-center justify-center"
                        style={{ background: `radial-gradient(circle, ${selectedTile.colorHex} 0%, #0c1922 100%)` }}
                      >
                        <ImageIcon size={32} className="text-[#ead654]" />
                      </div>
                    )}

                    <div className="absolute bottom-2 right-2 bg-black/80 px-2.5 py-1 rounded text-[10px] font-mono text-[#ead654] border border-[#ead654]/30">
                      View ({activeImageIndex + 1}/{selectedTile.images?.length || 1})
                    </div>
                  </div>

                  {/* Thumbnail selector if multiple images exist */}
                  {selectedTile.images && selectedTile.images.length > 1 && (
                    <div className="flex gap-2 mt-2 pt-2 border-t border-[#ead654]/20 justify-center">
                      {selectedTile.images.map((imgUrl, idx) => (
                        <button
                          key={idx}
                          onClick={() => setActiveImageIndex(idx)}
                          className={`w-12 h-12 sm:w-14 sm:h-14 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                            activeImageIndex === idx ? 'border-[#ead654] scale-105' : 'border-transparent opacity-60 hover:opacity-100'
                          }`}
                        >
                          <img src={imgUrl} alt="Thumbnail" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <p className="text-xs sm:text-sm text-neutral-200 font-normal leading-relaxed">
                  {selectedTile.description}
                </p>

                {/* Technical Specifications */}
                <div className="grid grid-cols-2 gap-2.5 sm:gap-3 p-3.5 bg-[#0c1922] border border-[#ead654]/25 rounded-xl text-xs">
                  <div>
                    <span className="text-[9px] font-mono text-[#ead654] uppercase block font-bold">Material Body</span>
                    <span className="text-white font-semibold">{selectedTile.body}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-mono text-[#ead654] uppercase block font-bold">Glaze Finish</span>
                    <span className="text-white font-semibold">{selectedTile.glazeFinish}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-mono text-[#ead654] uppercase block font-bold">Dimensions</span>
                    <span className="text-white font-semibold">{selectedTile.dimensions}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-mono text-[#ead654] uppercase block font-bold">Origin</span>
                    <span className="text-white font-semibold">{selectedTile.origin}</span>
                  </div>
                </div>

                {/* Architectural Features */}
                <div className="space-y-1.5 pt-1">
                  <span className="text-[10px] font-mono uppercase text-[#ead654] font-bold block">
                    Features & Specifications:
                  </span>
                  {selectedTile.features.map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-neutral-200">
                      <Check size={14} className="text-[#ead654] shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* FIXED / STICKY CTA FOOTER AT BOTTOM OF MODAL */}
              <div className="p-3.5 sm:p-4 bg-[#183242] border-t border-[#ead654]/30 shrink-0 shadow-lg flex flex-col sm:flex-row gap-2.5">
                {onOpenCalculator && (
                  <button
                    onClick={() => {
                      const tileName = selectedTile.name;
                      handleOpenModal(null);
                      onOpenCalculator(tileName);
                    }}
                    className="w-full sm:w-1/2 py-2.5 sm:py-3 px-3.5 bg-[#0c1922] border border-[#ead654]/50 hover:border-[#ead654] text-[#ead654] hover:text-white rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 font-sans active:scale-95"
                  >
                    <Calculator size={16} className="shrink-0" />
                    <span className="text-xs font-bold uppercase tracking-wider text-center">
                      Calculate Quantity
                    </span>
                  </button>
                )}

                <button
                  onClick={() => {
                    const tileName = selectedTile.name;
                    handleOpenModal(null);
                    onRequestSampleModal(tileName);
                  }}
                  className={`py-2.5 sm:py-3 px-3.5 bg-[#ead654] hover:bg-[#f3e371] active:scale-[0.98] text-[#183242] rounded-xl transition-all shadow-lg cursor-pointer flex items-center justify-center gap-2 font-sans ${
                    onOpenCalculator ? 'w-full sm:w-1/2' : 'w-full'
                  }`}
                >
                  <Sparkles size={16} className="shrink-0 text-[#183242]" />
                  <span className="text-xs font-extrabold uppercase tracking-wider text-center">
                    Request Sample Box
                  </span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FLOATING SCROLL TO TOP BUTTON */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={handleScrollToTop}
            className="fixed bottom-14 sm:bottom-16 right-4 sm:right-8 z-40 p-3 rounded-full bg-[#183242] border-2 border-[#ead654] text-[#ead654] hover:bg-[#ead654] hover:text-[#183242] shadow-2xl transition-all cursor-pointer flex items-center justify-center group active:scale-95"
            title="Scroll to Top"
            aria-label="Scroll to Top"
          >
            <ChevronUp size={20} className="group-hover:-translate-y-0.5 transition-transform" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
