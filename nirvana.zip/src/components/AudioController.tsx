import { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

export default function AudioController() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorsRef = useRef<OscillatorNode[]>([]);
  const gainNodeRef = useRef<GainNode | null>(null);
  const filterNodeRef = useRef<BiquadFilterNode | null>(null);
  const lfoRef = useRef<OscillatorNode | null>(null);

  const initAudio = () => {
    if (audioCtxRef.current) return;

    // Create AudioContext
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    audioCtxRef.current = ctx;

    // Main volume gain
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0, ctx.currentTime);
    masterGain.connect(ctx.destination);
    gainNodeRef.current = masterGain;

    // Lowpass filter for smooth, warm ambient sound
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(320, ctx.currentTime);
    filter.Q.setValueAtTime(1, ctx.currentTime);
    filter.connect(masterGain);
    filterNodeRef.current = filter;

    // Harmonic minor / major warm ambient chord notes (frequencies in Hz)
    // C2 (65.41), G2 (98.00), C3 (130.81), E3 (164.81), G3 (196.00)
    const notes = [65.41, 98.00, 130.81, 164.81, 196.00];
    const oscillators: OscillatorNode[] = [];

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      // Triangle and sine waves for a smooth, warm flute/organ-like texture
      osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);

      // Create local gain node for each harmonic to blend them nicely
      const oscGain = ctx.createGain();
      // Lower frequency gets more weight, higher frequencies are very soft
      const volume = idx === 0 ? 0.3 : idx === 1 ? 0.2 : 0.1;
      oscGain.gain.setValueAtTime(volume, ctx.currentTime);

      osc.connect(oscGain);
      oscGain.connect(filter);
      osc.start();
      oscillators.push(osc);
    });

    oscillatorsRef.current = oscillators;

    // Low Frequency Oscillator (LFO) to modulate the lowpass filter frequency
    // for a slowly sweeping organic feel
    const lfo = ctx.createOscillator();
    lfo.frequency.setValueAtTime(0.08, ctx.currentTime); // very slow sweep: 12 seconds per cycle

    const lfoGain = ctx.createGain();
    lfoGain.gain.setValueAtTime(120, ctx.currentTime); // modulate up/down by 120Hz

    lfo.connect(lfoGain);
    if (filter.frequency) {
      lfoGain.connect(filter.frequency);
    }
    lfo.start();
    lfoRef.current = lfo;
  };

  const toggleSound = async () => {
    try {
      if (!audioCtxRef.current) {
        initAudio();
      }

      const ctx = audioCtxRef.current;
      const masterGain = gainNodeRef.current;

      if (!ctx || !masterGain) return;

      if (isPlaying) {
        // Fade out smoothly over 1.5 seconds
        masterGain.gain.setValueAtTime(masterGain.gain.value, ctx.currentTime);
        masterGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5);
        setTimeout(() => {
          if (ctx.state === 'running' && !isPlaying) {
            ctx.suspend();
          }
        }, 1500);
        setIsPlaying(false);
      } else {
        if (ctx.state === 'suspended') {
          await ctx.resume();
        }
        // Fade in smoothly over 2 seconds
        masterGain.gain.setValueAtTime(masterGain.gain.value, ctx.currentTime);
        masterGain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 2.0);
        setIsPlaying(true);
      }
    } catch (e) {
      console.warn("Audio initialization failed or blocked by browser security.", e);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      oscillatorsRef.current.forEach(osc => {
        try { osc.stop(); } catch(e) {}
      });
      if (lfoRef.current) {
        try { lfoRef.current.stop(); } catch(e) {}
      }
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
      }
    };
  }, []);

  return (
    <div className="flex items-center gap-2">
      {isPlaying && (
        <span className="hidden md:inline text-[9px] font-mono tracking-widest text-[#ead654] uppercase animate-pulse">
          Audio On
        </span>
      )}
      <button
        id="audio-toggle-btn"
        onClick={toggleSound}
        className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-lg backdrop-blur-md active:scale-95 border ${
          isPlaying
            ? 'bg-[#ead654] text-[#183242] border-[#ead654] shadow-[#ead654]/30'
            : 'bg-[#183242]/90 hover:bg-[#183242] text-[#ead654] border-[#ead654]/40'
        }`}
        aria-label="Toggle ambient sound"
        title={isPlaying ? "Mute Ambient Sound" : "Play Relaxing Ambient Sound"}
      >
        {isPlaying ? (
          <Volume2 size={16} className="animate-pulse" />
        ) : (
          <VolumeX size={16} />
        )}
      </button>
    </div>
  );
}
