import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calculator, X, Check, Copy, Sparkles, Scale, Box, Grid, Plus, Trash2, Pencil, Info, Download, FileText, Factory, ShieldCheck, QrCode, Printer, Search, ChevronDown, ChevronUp, Building2 } from 'lucide-react';

export interface FactorySpec {
  id: string;
  name: string;
  code: string;
  densityKgM2: number;
  boxCapacityM2: number;
  description: string;
  supportedSizes: string[];
}

export const FACTORIES: FactorySpec[] = [
  {
    id: 'default',
    name: 'Standard System Default',
    code: 'STD',
    densityKgM2: 20.5,
    boxCapacityM2: 1.44,
    description: 'System Standard Calculation (20.5 kg/m²)',
    supportedSizes: ['30x60', '60x60', '60x120', '120x120', '80x80', 'custom'],
  },
  {
    id: 'persepolis',
    name: 'Persepolis Tile Co.',
    code: 'PRS',
    densityKgM2: 21.0,
    boxCapacityM2: 1.44,
    description: 'Glazed Porcelain & Architectural Slabs',
    supportedSizes: ['60x60', '60x120', '120x120'],
  },
  {
    id: 'eefa',
    name: 'Eefa Ceram',
    code: 'EFA',
    densityKgM2: 20.2,
    boxCapacityM2: 1.44,
    description: 'Polished Ceramic & Floor Formats',
    supportedSizes: ['30x60', '60x60', '80x80'],
  },
  {
    id: 'amin',
    name: 'Amin Porcelain',
    code: 'AMN',
    densityKgM2: 22.5,
    boxCapacityM2: 1.44,
    description: 'Heavy-Duty Commercial & Outdoor Formats',
    supportedSizes: ['60x60', '60x120'],
  },
  {
    id: 'behnam',
    name: 'Behnam Tile',
    code: 'BHN',
    densityKgM2: 19.8,
    boxCapacityM2: 1.44,
    description: 'Lightweight Decorative & Wall Tile',
    supportedSizes: ['30x60', '60x60'],
  },
  {
    id: 'tabriz',
    name: 'Tabriz Tile Group',
    code: 'TBZ',
    densityKgM2: 21.8,
    boxCapacityM2: 1.44,
    description: 'Tech Porcelain & Grand Slabs',
    supportedSizes: ['60x120', '120x120', '80x80'],
  },
  {
    id: 'alborz',
    name: 'Alborz Ceramic Industrial Group',
    code: 'ALB',
    densityKgM2: 20.5,
    boxCapacityM2: 1.44,
    description: 'Pool & Architectural Mosaics',
    supportedSizes: ['30x60', '60x60'],
  },
  {
    id: 'sina',
    name: 'Sina Tile & Ceramic',
    code: 'SNA',
    densityKgM2: 21.2,
    boxCapacityM2: 1.44,
    description: 'High-Traffic Industrial Slabs',
    supportedSizes: ['60x120', '120x120'],
  },
  {
    id: 'rock',
    name: 'Rock Ceram Porcelain',
    code: 'RCK',
    densityKgM2: 22.0,
    boxCapacityM2: 1.44,
    description: 'Full-Body Technical Slabs',
    supportedSizes: ['60x60', '60x120', '120x120'],
  },
  {
    id: 'yazd',
    name: 'Yazd Ceramic Group',
    code: 'YZD',
    densityKgM2: 20.0,
    boxCapacityM2: 1.44,
    description: 'Traditional Glazed & Wall Panels',
    supportedSizes: ['30x60', '60x60'],
  },
  {
    id: 'marjan',
    name: 'Marjan Tile Co.',
    code: 'MRJ',
    densityKgM2: 21.6,
    boxCapacityM2: 1.44,
    description: 'Acid-Resistant Industrial Porcelain',
    supportedSizes: ['30x60', '60x60', '60x120'],
  },
];

export interface TilePreset {
  id: string;
  name: string;
  widthCm: number;
  heightCm: number;
  tilesPerBox: number;
  isCustom?: boolean;
}

export const TILE_PRESETS: TilePreset[] = [
  { id: 'velvet-60', name: 'Velvet Soft 60×60 cm', widthCm: 60, heightCm: 60, tilesPerBox: 4 },
  { id: 'studio-30-60', name: 'Velvet Studio 30×60 cm', widthCm: 30, heightCm: 60, tilesPerBox: 8 },
  { id: 'slab-120-60', name: 'Architectural Slab 120×60 cm', widthCm: 120, heightCm: 60, tilesPerBox: 2 },
  { id: 'slab-120-120', name: 'Grand Slab 120×120 cm', widthCm: 120, heightCm: 120, tilesPerBox: 1 },
  { id: 'square-80', name: 'Porcelain 80×80 cm', widthCm: 80, heightCm: 80, tilesPerBox: 3 },
  { id: 'custom', name: 'Custom Dimensions', widthCm: 60, heightCm: 60, tilesPerBox: 4, isCustom: true },
];

export interface RoomItem {
  id: string;
  name: string;
  calcMode: 'dimensions' | 'area';
  length: number;
  width: number;
  directArea: number;
  includeWalls: boolean;
  wallHeight: number;
  wastagePct: number;
  factoryId: string;
  // Per-room tile format selection
  presetId: string;
  customWidthCm?: number;
  customHeightCm?: number;
  customTilesPerBox?: number;
}

export const getRoomSizeKey = (room: RoomItem): string => {
  if (room.presetId === 'studio-30-60') return '30x60';
  if (room.presetId === 'velvet-60') return '60x60';
  if (room.presetId === 'slab-120-60') return '60x120';
  if (room.presetId === 'slab-120-120') return '120x120';
  if (room.presetId === 'square-80') return '80x80';

  if (room.presetId === 'custom') {
    const w = room.customWidthCm || 60;
    const h = room.customHeightCm || 60;
    if ((w === 30 && h === 60) || (w === 60 && h === 30)) return '30x60';
    if (w === 60 && h === 60) return '60x60';
    if ((w === 120 && h === 60) || (w === 60 && h === 120)) return '60x120';
    if (w === 120 && h === 120) return '120x120';
    if (w === 80 && h === 80) return '80x80';
  }
  return 'custom';
};

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onApplyToQuote: (summaryText: string) => void;
  preselectedTileName?: string;
}

export default function CalculatorModal({
  isOpen,
  onClose,
  onApplyToQuote,
  preselectedTileName,
}: Props) {
  // Unit toggle
  const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');

  // Info modal & Certificate modal state
  const [showCustomInfo, setShowCustomInfo] = useState(false);
  const [showCertificateModal, setShowCertificateModal] = useState(false);

  // Searchable Factory bar state per room
  const [expandedFactoryRoomId, setExpandedFactoryRoomId] = useState<string | null>(null);
  const [factorySearchQuery, setFactorySearchQuery] = useState('');

  // Rooms state (multi-room support with per-room format and factory selection)
  const [rooms, setRooms] = useState<RoomItem[]>([
    {
      id: 'room-1',
      name: 'Room 1 (Main Area)',
      calcMode: 'dimensions',
      length: 5.0,
      width: 4.0,
      directArea: 20.0,
      includeWalls: false,
      wallHeight: 2.5,
      wastagePct: 10,
      factoryId: 'default',
      presetId: 'velvet-60',
      customWidthCm: 60,
      customHeightCm: 60,
      customTilesPerBox: 4,
    },
  ]);

  // Copy feedback state
  const [copied, setCopied] = useState(false);

  // Room Management Actions
  const handleAddRoom = () => {
    const newRoomNumber = rooms.length + 1;
    setRooms((prev) => [
      ...prev,
      {
        id: `room-${Date.now()}`,
        name: `Room ${newRoomNumber}`,
        calcMode: 'dimensions',
        length: 4.0,
        width: 3.0,
        directArea: 12.0,
        includeWalls: false,
        wallHeight: 2.5,
        wastagePct: 10,
        factoryId: 'default',
        presetId: 'velvet-60',
        customWidthCm: 60,
        customHeightCm: 60,
        customTilesPerBox: 4,
      },
    ]);
  };

  const handleRemoveRoom = (id: string) => {
    if (rooms.length <= 1) return;
    setRooms((prev) => prev.filter((r) => r.id !== id));
  };

  const handleUpdateRoom = <K extends keyof RoomItem>(id: string, key: K, value: RoomItem[K]) => {
    setRooms((prev) =>
      prev.map((r) => (r.id === id ? { ...r, [key]: value } : r))
    );
  };

  // Calculations per room and grand totals
  const roomCalculations = useMemo(() => {
    let grandNetAreaM2 = 0;
    let grandGrossAreaM2 = 0;
    let grandExactTiles = 0;
    let grandExactBoxes = 0;
    let grandSuppliedM2 = 0;
    let grandWeightKg = 0;

    const details = rooms.map((room) => {
      // Find factory spec
      const factory = FACTORIES.find((f) => f.id === room.factoryId) || FACTORIES[0];

      // Find preset or custom spec for THIS room
      let widthCm = 60;
      let heightCm = 60;
      let tilesPerBox = 4;
      let formatName = 'Velvet Soft 60×60 cm';

      if (room.presetId === 'custom') {
        widthCm = room.customWidthCm || 60;
        heightCm = room.customHeightCm || 60;
        tilesPerBox = room.customTilesPerBox || 1;
        formatName = `Custom (${widthCm}×${heightCm} cm)`;
      } else {
        const found = TILE_PRESETS.find((p) => p.id === room.presetId) || TILE_PRESETS[0];
        widthCm = found.widthCm;
        heightCm = found.heightCm;
        tilesPerBox = found.tilesPerBox;
        formatName = found.name;
      }

      const tileWidthM = widthCm / 100;
      const tileHeightM = heightCm / 100;
      const singleTileAreaM2 = tileWidthM * tileHeightM;
      const m2PerBox = singleTileAreaM2 * tilesPerBox;

      let netM2 = 0;
      if (room.calcMode === 'dimensions') {
        if (unit === 'metric') {
          netM2 = (room.length || 0) * (room.width || 0);
        } else {
          netM2 = (room.length || 0) * (room.width || 0) * 0.092903;
        }

        if (room.includeWalls) {
          const perimeterM =
            unit === 'metric'
              ? (room.length + room.width) * 2
              : (room.length + room.width) * 2 * 0.3048;
          const heightM = unit === 'metric' ? room.wallHeight : room.wallHeight * 0.3048;
          netM2 += perimeterM * heightM;
        }
      } else {
        if (unit === 'metric') {
          netM2 = room.directArea || 0;
        } else {
          netM2 = (room.directArea || 0) * 0.092903;
        }
      }

      const grossM2 = netM2 * (1 + (room.wastagePct || 0) / 100);
      const exactTiles = singleTileAreaM2 > 0 ? Math.ceil(grossM2 / singleTileAreaM2) : 0;
      const exactBoxes = m2PerBox > 0 ? Math.ceil(grossM2 / m2PerBox) : 0;
      const suppliedM2 = exactBoxes * m2PerBox;
      const roomWeightKg = Math.round(suppliedM2 * factory.densityKgM2);

      grandNetAreaM2 += netM2;
      grandGrossAreaM2 += grossM2;
      grandExactTiles += exactTiles;
      grandExactBoxes += exactBoxes;
      grandSuppliedM2 += suppliedM2;
      grandWeightKg += roomWeightKg;

      return {
        ...room,
        factoryName: factory.name,
        factoryCode: factory.code,
        factoryDensity: factory.densityKgM2,
        formatName,
        widthCm,
        heightCm,
        tilesPerBox,
        singleTileAreaM2,
        m2PerBox,
        netM2,
        netSqFt: netM2 * 10.7639,
        grossM2,
        grossSqFt: grossM2 * 10.7639,
        exactTiles,
        exactBoxes,
        suppliedM2,
        roomWeightKg,
      };
    });

    const grandWeightLbs = Math.round(grandWeightKg * 2.20462);

    return {
      details,
      grandNetAreaM2,
      grandNetAreaSqFt: grandNetAreaM2 * 10.7639,
      grandGrossAreaM2,
      grandGrossAreaSqFt: grandGrossAreaM2 * 10.7639,
      grandExactTiles,
      grandExactBoxes,
      grandSuppliedM2,
      grandSuppliedSqFt: grandSuppliedM2 * 10.7639,
      grandWeightKg,
      grandWeightLbs,
    };
  }, [rooms, unit]);

  // Clean professional copy summary text with single link at bottom
  const calculationSummaryText = useMemo(() => {
    const tileLabel = preselectedTileName ? `PRODUCT SPECIFICATION: ${preselectedTileName}\n` : '';
    let text = `NIRVANA ARCHITECTURAL SPECIFICATION ESTIMATE\n`;
    text += `${tileLabel}\n`;
    text += `ROOM BREAKDOWN (${rooms.length} ${rooms.length === 1 ? 'Area' : 'Areas'}):\n`;
    
    roomCalculations.details.forEach((r, idx) => {
      text += `${idx + 1}. ${r.name}:\n`;
      text += `   • Format: ${r.formatName} (${r.widthCm}×${r.heightCm} cm, ${r.tilesPerBox} pcs/box)\n`;
      text += `   • Manufacturing Factory: ${r.factoryName} (${r.factoryCode})\n`;
      text += `   • Net Surface: ${r.netM2.toFixed(1)} m² (+${r.wastagePct}% wastage => ${r.grossM2.toFixed(1)} m²)\n`;
      text += `   • Material Required: ${r.exactBoxes} boxes (${r.exactTiles} tiles)\n\n`;
    });

    text += `GRAND TOTALS:\n`;
    text += `• Total Net Area: ${roomCalculations.grandNetAreaM2.toFixed(2)} m² (${roomCalculations.grandNetAreaSqFt.toFixed(1)} sq ft)\n`;
    text += `• Total Gross Area: ${roomCalculations.grandGrossAreaM2.toFixed(2)} m² (${roomCalculations.grandGrossAreaSqFt.toFixed(1)} sq ft)\n`;
    text += `• Total Material Required: ${roomCalculations.grandExactBoxes} boxes (${roomCalculations.grandSuppliedM2.toFixed(2)} m² / ${roomCalculations.grandExactTiles} tiles)\n`;
    text += `• Est. Freight Weight: ~${roomCalculations.grandWeightKg} kg (${roomCalculations.grandWeightLbs} lbs)\n\n`;
    text += `Official Catalog & Verification: https://nirvanaport.com`;

    return text;
  }, [preselectedTileName, rooms, roomCalculations]);

  const handleCopySummary = async () => {
    try {
      await navigator.clipboard.writeText(calculationSummaryText);
    } catch (e) {
      // fallback
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const handleApplyToForm = () => {
    onApplyToQuote(calculationSummaryText);
    onClose();
  };

  // Canvas PNG Generator for Specification & Freight Report Sheet
  const handleDownloadPNG = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1000;
    canvas.height = 1250;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Canvas Background
    ctx.fillStyle = '#183242';
    ctx.fillRect(0, 0, 1000, 1250);

    // Gold Outer Frame
    ctx.strokeStyle = '#ead654';
    ctx.lineWidth = 8;
    ctx.strokeRect(24, 24, 952, 1202);

    // Diagonal Background Security Watermark
    ctx.save();
    ctx.rotate(-Math.PI / 8);
    ctx.fillStyle = 'rgba(234, 214, 84, 0.035)';
    ctx.font = 'bold 28px monospace';
    for (let y = -300; y < 1600; y += 100) {
      ctx.fillText('OFFICIAL SPECIFICATION REPORT • NIRVANAPORT.COM • APPROXIMATE ESTIMATE', -200, y);
    }
    ctx.restore();

    // Header Logo Banner
    ctx.fillStyle = '#ead654';
    ctx.font = 'bold 30px sans-serif';
    ctx.fillText('NIRVANA ARCHITECTURAL TILES', 60, 80);
    ctx.fillStyle = '#ffffff';
    ctx.font = '18px sans-serif';
    ctx.fillText('Material Specification & Freight Calculation Report', 60, 112);

    ctx.strokeStyle = 'rgba(234, 214, 84, 0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(60, 130);
    ctx.lineTo(940, 130);
    ctx.stroke();

    // Document Meta
    let curY = 175;
    ctx.font = 'bold 15px monospace';
    ctx.fillStyle = '#ead654';
    const reportCode = `NIR-REP-${Math.floor(100000 + Math.random() * 900000)}`;
    ctx.fillText(`REPORT REFERENCE: ${reportCode}`, 60, curY);
    ctx.fillText(`WEBSITE: https://nirvanaport.com`, 580, curY);
    curY += 35;

    if (preselectedTileName) {
      ctx.font = '16px sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`Product: ${preselectedTileName}`, 60, curY);
      curY += 35;
    }

    // Room Table Header
    ctx.fillStyle = '#0c1922';
    ctx.fillRect(60, curY, 880, 42);
    ctx.fillStyle = '#ead654';
    ctx.font = 'bold 13px monospace';
    ctx.fillText('ROOM / AREA', 80, curY + 26);
    ctx.fillText('FORMAT', 300, curY + 26);
    ctx.fillText('FACTORY SPEC', 490, curY + 26);
    ctx.fillText('NET / GROSS AREA', 670, curY + 26);
    ctx.fillText('BOXES', 850, curY + 26);
    curY += 46;

    roomCalculations.details.forEach((r, idx) => {
      ctx.fillStyle = idx % 2 === 0 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.2)';
      ctx.fillRect(60, curY, 880, 40);
      ctx.fillStyle = '#ffffff';
      ctx.font = '14px sans-serif';
      ctx.fillText(`${idx + 1}. ${r.name}`, 80, curY + 25);
      ctx.fillText(`${r.widthCm}×${r.heightCm} cm`, 300, curY + 25);
      ctx.fillText(`${r.factoryCode}`, 490, curY + 25);
      ctx.fillText(`${r.netM2.toFixed(1)} m² (${r.grossM2.toFixed(1)} m²)`, 670, curY + 25);
      ctx.fillStyle = '#ead654';
      ctx.font = 'bold 14px monospace';
      ctx.fillText(`${r.exactBoxes} boxes`, 850, curY + 25);
      curY += 44;
    });

    curY += 20;
    // Grand Totals Summary Card
    ctx.fillStyle = '#0c1922';
    ctx.fillRect(60, curY, 880, 180);
    ctx.strokeStyle = '#ead654';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(60, curY, 880, 180);

    ctx.fillStyle = '#ead654';
    ctx.font = 'bold 18px sans-serif';
    ctx.fillText('PROJECT GRAND TOTALS & FREIGHT METRICS', 90, curY + 40);

    ctx.fillStyle = '#ffffff';
    ctx.font = '15px monospace';
    ctx.fillText(`• Total Net Surface Area: ${roomCalculations.grandNetAreaM2.toFixed(2)} m² (${roomCalculations.grandNetAreaSqFt.toFixed(1)} sq ft)`, 90, curY + 75);
    ctx.fillText(`• Total Material Required: ${roomCalculations.grandExactBoxes} Boxes (${roomCalculations.grandSuppliedM2.toFixed(2)} m² / ${roomCalculations.grandExactTiles} tiles)`, 90, curY + 110);
    ctx.fillText(`• Estimated Freight Weight: ~${roomCalculations.grandWeightKg} kg (${roomCalculations.grandWeightLbs} lbs)`, 90, curY + 145);

    curY += 205;

    // Disclaimer Box
    ctx.fillStyle = '#142937';
    ctx.fillRect(60, curY, 880, 95);
    ctx.strokeStyle = 'rgba(234, 214, 84, 0.4)';
    ctx.lineWidth = 1;
    ctx.strokeRect(60, curY, 880, 95);

    ctx.fillStyle = '#ead654';
    ctx.font = 'bold 13px monospace';
    ctx.fillText('📌 APPROXIMATE ESTIMATION NOTICE:', 80, curY + 28);
    ctx.fillStyle = '#cbd5e1';
    ctx.font = '13px sans-serif';
    ctx.fillText('All numbers in this report are approximate estimates for initial project planning.', 80, curY + 52);
    ctx.fillText('For exact tile quantities, custom cutting plans, and official quotes, please contact us directly.', 80, curY + 74);

    curY += 120;

    // QR Code & Footer Section
    // Draw real QR Code of nirvanaport.com on canvas
    const drawQR = (qrImg?: HTMLImageElement) => {
      const qrSize = 110;
      const qrX = 830;
      const qrY = curY - 20;

      if (qrImg && qrImg.complete && qrImg.naturalWidth > 0) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(qrX - 5, qrY - 5, qrSize + 10, qrSize + 10);
        ctx.drawImage(qrImg, qrX, qrY, qrSize, qrSize);
      } else {
        // High quality fallback vector QR code matrix for nirvanaport.com
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(qrX - 5, qrY - 5, qrSize + 10, qrSize + 10);

        const pad = 4;
        const grid = 21;
        const mod = (qrSize - pad * 2) / grid;
        const dark = '#0c1922';

        const drawFinderPattern = (gx: number, gy: number) => {
          const fx = qrX + pad + gx * mod;
          const fy = qrY + pad + gy * mod;
          ctx.fillStyle = dark;
          ctx.fillRect(fx, fy, 7 * mod, 7 * mod);
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(fx + mod, fy + mod, 5 * mod, 5 * mod);
          ctx.fillStyle = dark;
          ctx.fillRect(fx + 2 * mod, fy + 2 * mod, 3 * mod, 3 * mod);
        };

        drawFinderPattern(0, 0);
        drawFinderPattern(14, 0);
        drawFinderPattern(0, 14);

        ctx.fillStyle = dark;
        const qrModules: [number, number][] = [
          [8,2],[8,4],[8,5],[9,8],[10,8],[11,8],[12,8],
          [2,8],[4,8],[5,8],[7,8],[7,10],[7,12],[7,13],
          [9,10],[11,10],[12,11],[13,9],[14,8],[15,10],[16,12],
          [8,14],[8,16],[8,18],[9,14],[10,16],[11,18],[12,14],
          [14,14],[15,15],[16,16],[17,17],[18,18],[19,19],[20,20],
          [10,2],[12,4],[14,3],[16,5],[18,2],[20,4],
          [2,10],[4,12],[3,14],[5,16],[2,18],[4,20],
          [12,12],[13,13],[14,12],[15,13],[16,14],[17,15],
          [18,8],[19,10],[20,12],[8,20],[10,20],[12,20]
        ];
        qrModules.forEach(([mx, my]) => {
          ctx.fillRect(qrX + pad + mx * mod, qrY + pad + my * mod, mod, mod);
        });
      }

      ctx.fillStyle = '#ead654';
      ctx.font = 'bold 15px monospace';
      ctx.fillText('NIRVANA PORT — ARCHITECTURAL TILES & SLAB CATALOG', 60, curY + 20);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '13px sans-serif';
      ctx.fillText('Visit https://nirvanaport.com or scan QR code to explore full product lines.', 60, curY + 44);

      // Trigger download
      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = `Nirvana-Tile-Report-${reportCode}.png`;
      link.click();
    };

    // Try loading live QR code image, fallback to drawn canvas QR code if offline or blocked
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => drawQR(img);
    img.onerror = () => drawQR();
    img.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://nirvanaport.com`;
    // Timeout fallback if image load takes more than 400ms
    setTimeout(() => {
      if (!img.complete) drawQR();
    }, 400);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 select-none pointer-events-auto">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/85 backdrop-blur-md cursor-pointer"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 15 }}
            transition={{ type: 'spring', damping: 26, stiffness: 280 }}
            className="relative w-[92%] sm:w-full max-w-3xl bg-[#183242] border border-[#ead654]/40 rounded-2xl sm:rounded-3xl text-white shadow-2xl z-10 overflow-hidden max-h-[82vh] sm:max-h-[88vh] flex flex-col my-auto"
          >
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-[#ead654]/20 flex justify-between items-center shrink-0 bg-[#183242]">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#ead654]/15 border border-[#ead654]/30 flex items-center justify-center text-[#ead654]">
                  <Calculator size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono tracking-widest text-[#ead654] uppercase font-bold">
                      NIRVANA ARCHITECTURAL CALCULATOR
                    </span>
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold tracking-tight text-white">
                    Multi-Room Tile & Factory Estimator
                  </h3>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-black/40 hover:bg-black/70 text-neutral-300 hover:text-white flex items-center justify-center transition-all cursor-pointer shrink-0 border border-[#ead654]/30 active:scale-95"
                aria-label="Close modal"
              >
                <X size={16} />
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="p-4 sm:p-6 overflow-y-auto custom-scrollbar grow space-y-6 text-sm">
              
              {/* Unit selector & Multi-Room Section */}
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-xs font-mono uppercase text-[#ead654] font-bold tracking-wider flex items-center gap-1.5">
                    <Grid size={13} /> Project Rooms, Factory & Format Specifications
                  </h4>

                  <div className="flex items-center gap-2 bg-[#0c1922] p-1 rounded-xl border border-[#ead654]/20">
                    <button
                      onClick={() => setUnit('metric')}
                      className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                        unit === 'metric'
                          ? 'bg-[#ead654] text-[#183242]'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      Meters (m)
                    </button>
                    <button
                      onClick={() => setUnit('imperial')}
                      className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                        unit === 'imperial'
                          ? 'bg-[#ead654] text-[#183242]'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      Feet (ft)
                    </button>
                  </div>
                </div>

                {/* Transportation & Customs Notice */}
                <div className="bg-[#0c1922] p-3 rounded-xl border border-[#ead654]/30 text-xs text-neutral-200 flex items-start gap-2.5 shadow-sm">
                  <Info size={16} className="text-[#ead654] shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <span className="font-bold text-[#ead654] block">Logistics & Customs Notice:</span>
                    <p className="text-neutral-300 leading-relaxed">
                      Approximately transportation to border is about <strong>$400</strong> and the Customs cost about <strong>$150</strong>. If you want to know exact numbers, please contact us.
                    </p>
                  </div>
                </div>

                {/* List of Rooms */}
                <div className="space-y-4">
                  {rooms.map((room, idx) => {
                    const roomCalc = roomCalculations.details[idx];
                    return (
                      <div
                        key={room.id}
                        className="bg-[#0c1922] p-3.5 sm:p-4 rounded-xl border border-[#ead654]/25 space-y-3.5 relative"
                      >
                        {/* Room Header */}
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#ead654]/15 pb-2">
                          <div className="flex items-center gap-1.5 bg-[#183242]/80 hover:bg-[#183242] border border-[#ead654]/30 focus-within:border-[#ead654] px-2.5 py-1 rounded-lg transition-all group">
                            <input
                              type="text"
                              value={room.name}
                              onChange={(e) => handleUpdateRoom(room.id, 'name', e.target.value)}
                              className="bg-transparent text-xs sm:text-sm font-bold text-white focus:outline-none w-36 sm:w-48"
                              placeholder="Room Name"
                            />
                            <Pencil size={12} className="text-[#ead654] opacity-80 group-hover:opacity-100 shrink-0" title="Click to edit room name" />
                          </div>

                          <div className="flex items-center gap-2">
                            {/* Mode Toggle for room */}
                            <div className="flex items-center gap-1 bg-[#183242] p-0.5 rounded border border-[#ead654]/20">
                              <button
                                onClick={() => handleUpdateRoom(room.id, 'calcMode', 'dimensions')}
                                className={`px-2 py-0.5 text-[10px] font-semibold rounded ${
                                  room.calcMode === 'dimensions'
                                    ? 'bg-[#ead654] text-[#183242]'
                                    : 'text-neutral-400 hover:text-white'
                                }`}
                              >
                                L × W
                              </button>
                              <button
                                onClick={() => handleUpdateRoom(room.id, 'calcMode', 'area')}
                                className={`px-2 py-0.5 text-[10px] font-semibold rounded ${
                                  room.calcMode === 'area'
                                    ? 'bg-[#ead654] text-[#183242]'
                                    : 'text-neutral-400 hover:text-white'
                                }`}
                              >
                                Direct Area
                              </button>
                            </div>

                            {rooms.length > 1 && (
                              <button
                                onClick={() => handleRemoveRoom(room.id)}
                                className="text-red-400 hover:text-red-300 p-1 hover:bg-red-500/10 rounded transition-colors"
                                title="Remove Room"
                              >
                                <Trash2 size={14} />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Factory Selection Search Bar & Status */}
                        {(() => {
                          const roomSizeKey = getRoomSizeKey(room);
                          const factoriesForSize = FACTORIES.filter(
                            (f) => f.id === 'default' || f.supportedSizes.includes(roomSizeKey) || roomSizeKey === 'custom'
                          );
                          const currentFactory =
                            FACTORIES.find((f) => f.id === (room.factoryId || 'default')) || FACTORIES[0];
                          const isSearchOpen = expandedFactoryRoomId === room.id;
                          const filteredFactories = factoriesForSize.filter(
                            (f) =>
                              f.name.toLowerCase().includes(factorySearchQuery.toLowerCase()) ||
                              f.code.toLowerCase().includes(factorySearchQuery.toLowerCase()) ||
                              f.description.toLowerCase().includes(factorySearchQuery.toLowerCase())
                          );

                          return (
                            <div className="space-y-2 bg-[#183242]/50 p-3 rounded-xl border border-[#ead654]/20 transition-all">
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                                <label className="text-[10px] font-mono uppercase text-[#ead654] font-bold flex items-center gap-1.5">
                                  <Factory size={13} /> Factory Specification ({roomSizeKey}):
                                </label>

                                <button
                                  type="button"
                                  onClick={() => {
                                    if (isSearchOpen) {
                                      setExpandedFactoryRoomId(null);
                                    } else {
                                      setExpandedFactoryRoomId(room.id);
                                      setFactorySearchQuery('');
                                    }
                                  }}
                                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#0c1922] border border-[#ead654]/40 hover:border-[#ead654] text-[#ead654] hover:text-white text-[10px] font-mono font-bold transition-all cursor-pointer self-start sm:self-auto"
                                >
                                  <Search size={12} />
                                  <span>{isSearchOpen ? 'Hide Factory Search' : 'Search & Select Factory'}</span>
                                  {isSearchOpen ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                                </button>
                              </div>

                              {/* Active Selected Factory Chip */}
                              <div className="flex flex-wrap items-center justify-between gap-2 bg-[#0c1922] px-3 py-2 rounded-lg border border-[#ead654]/15">
                                <div className="flex items-center gap-2 text-xs">
                                  <Building2 size={14} className="text-[#ead654] shrink-0" />
                                  <span className="text-white font-bold">{currentFactory.name}</span>
                                  <span className="text-[10px] font-mono bg-[#ead654]/15 text-[#ead654] px-1.5 py-0.5 rounded border border-[#ead654]/30 font-bold">
                                    {currentFactory.code}
                                  </span>
                                  <span className="text-[11px] text-neutral-400 hidden sm:inline">
                                    ({currentFactory.densityKgM2} kg/m²)
                                  </span>
                                </div>
                                {currentFactory.id === 'default' ? (
                                  <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-1.5 py-0.5 rounded">
                                    System Default
                                  </span>
                                ) : (
                                  <button
                                    onClick={() => handleUpdateRoom(room.id, 'factoryId', 'default')}
                                    className="text-[9px] font-mono text-neutral-400 hover:text-[#ead654] underline cursor-pointer"
                                  >
                                    Reset to Default
                                  </button>
                                )}
                              </div>

                              {/* Expandable Search Bar & Factory Grid */}
                              {isSearchOpen && (
                                <motion.div
                                  initial={{ opacity: 0, height: 0 }}
                                  animate={{ opacity: 1, height: 'auto' }}
                                  exit={{ opacity: 0, height: 0 }}
                                  className="pt-2 border-t border-[#ead654]/15 space-y-2.5"
                                >
                                  <div className="relative">
                                    <Search size={14} className="absolute left-3 top-2.5 text-[#ead654]" />
                                    <input
                                      type="text"
                                      value={factorySearchQuery}
                                      onChange={(e) => setFactorySearchQuery(e.target.value)}
                                      placeholder={`Type factory name or code for ${roomSizeKey} (e.g. Persepolis, Eefa, Amin, Behnam, Tabriz)...`}
                                      className="w-full pl-9 pr-8 py-1.5 bg-[#0c1922] border border-[#ead654]/40 rounded-lg text-xs text-white placeholder-neutral-400 focus:outline-none focus:border-[#ead654]"
                                      autoFocus
                                    />
                                    {factorySearchQuery && (
                                      <button
                                        onClick={() => setFactorySearchQuery('')}
                                        className="absolute right-2.5 top-2 text-neutral-400 hover:text-white"
                                      >
                                        <X size={13} />
                                      </button>
                                    )}
                                  </div>

                                  <div className="flex items-center justify-between text-[10px] text-neutral-400 font-mono">
                                    <span>
                                      Showing {filteredFactories.length} factories producing {roomSizeKey} size
                                    </span>
                                    <span>Click to select & auto-calculate</span>
                                  </div>

                                  <div className="max-h-48 overflow-y-auto custom-scrollbar grid grid-cols-1 sm:grid-cols-2 gap-1.5 pr-1">
                                    {filteredFactories.length > 0 ? (
                                      filteredFactories.map((fac) => {
                                        const isSelected = (room.factoryId || 'default') === fac.id;
                                        return (
                                          <button
                                            key={fac.id}
                                            type="button"
                                            onClick={() => {
                                              handleUpdateRoom(room.id, 'factoryId', fac.id);
                                              setExpandedFactoryRoomId(null);
                                            }}
                                            className={`p-2 rounded-lg text-left transition-all border cursor-pointer flex flex-col justify-between gap-1 ${
                                              isSelected
                                                ? 'bg-[#ead654] text-[#183242] border-[#ead654] shadow-md font-bold'
                                                : 'bg-[#0c1922] border-[#ead654]/20 hover:border-[#ead654]/60 text-white'
                                            }`}
                                          >
                                            <div className="flex items-center justify-between">
                                              <span className="text-xs font-bold truncate">{fac.name}</span>
                                              <span
                                                className={`text-[9px] font-mono px-1 py-0.5 rounded font-bold ${
                                                  isSelected
                                                    ? 'bg-[#183242] text-[#ead654]'
                                                    : 'bg-[#ead654]/15 text-[#ead654]'
                                                }`}
                                              >
                                                {fac.code}
                                              </span>
                                            </div>
                                            <div
                                              className={`text-[10px] line-clamp-1 ${
                                                isSelected ? 'text-[#183242]/80 font-medium' : 'text-neutral-400'
                                              }`}
                                            >
                                              {fac.description} • {fac.densityKgM2} kg/m²
                                            </div>
                                          </button>
                                        );
                                      })
                                    ) : (
                                      <div className="col-span-2 text-center py-4 text-xs text-neutral-400 italic">
                                        No factories producing {roomSizeKey} matched &quot;{factorySearchQuery}&quot;.
                                      </div>
                                    )}
                                  </div>
                                </motion.div>
                              )}
                            </div>
                          );
                        })()}

                        {/* Room Specific Tile Format Picker */}
                        <div className="space-y-2 bg-[#183242]/60 p-2.5 rounded-lg border border-[#ead654]/15">
                          <div className="flex items-center justify-between">
                            <label className="text-[10px] font-mono uppercase text-[#ead654] font-bold flex items-center gap-1">
                              <Box size={12} /> Tile Format Selection:
                            </label>

                            {room.presetId === 'custom' && (
                              <button
                                onClick={() => setShowCustomInfo(true)}
                                className="flex items-center gap-1 text-[10px] font-mono text-[#ead654] hover:underline cursor-pointer bg-[#ead654]/10 px-1.5 py-0.5 rounded border border-[#ead654]/30"
                              >
                                <Info size={12} />
                                <span>Custom Rates Info</span>
                              </button>
                            )}
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                            {TILE_PRESETS.map((preset) => (
                              <button
                                key={preset.id}
                                onClick={() => handleUpdateRoom(room.id, 'presetId', preset.id)}
                                className={`px-2 py-1.5 rounded text-[11px] font-sans text-center transition-all cursor-pointer ${
                                  room.presetId === preset.id
                                    ? 'bg-[#ead654] text-[#183242] font-extrabold shadow'
                                    : 'bg-[#0c1922] border border-[#ead654]/20 text-neutral-300 hover:text-white'
                                }`}
                              >
                                {preset.isCustom ? 'Custom' : `${preset.widthCm}×${preset.heightCm} cm`}
                              </button>
                            ))}
                          </div>

                          {/* Custom dimensions if chosen for this room */}
                          {room.presetId === 'custom' && (
                            <div className="grid grid-cols-3 gap-2 pt-1.5 border-t border-[#ead654]/10">
                              <div>
                                <label className="text-[9px] font-mono text-neutral-300 uppercase flex items-center gap-1 mb-0.5">
                                  Width (cm)
                                </label>
                                <input
                                  type="number"
                                  value={room.customWidthCm ?? 60}
                                  onChange={(e) =>
                                    handleUpdateRoom(room.id, 'customWidthCm', parseFloat(e.target.value) || 0)
                                  }
                                  className="w-full h-7 px-2 bg-[#0c1922] border border-[#ead654]/30 rounded text-xs text-white font-mono font-bold"
                                />
                              </div>
                              <div>
                                <label className="text-[9px] font-mono text-neutral-300 uppercase flex items-center gap-1 mb-0.5">
                                  Height (cm)
                                </label>
                                <input
                                  type="number"
                                  value={room.customHeightCm ?? 60}
                                  onChange={(e) =>
                                    handleUpdateRoom(room.id, 'customHeightCm', parseFloat(e.target.value) || 0)
                                  }
                                  className="w-full h-7 px-2 bg-[#0c1922] border border-[#ead654]/30 rounded text-xs text-white font-mono font-bold"
                                />
                              </div>
                              <div>
                                <label className="text-[9px] font-mono text-neutral-300 uppercase flex items-center gap-1 mb-0.5">
                                  Pcs/Box
                                </label>
                                <input
                                  type="number"
                                  value={room.customTilesPerBox ?? 4}
                                  onChange={(e) =>
                                    handleUpdateRoom(room.id, 'customTilesPerBox', parseInt(e.target.value) || 1)
                                  }
                                  className="w-full h-7 px-2 bg-[#0c1922] border border-[#ead654]/30 rounded text-xs text-white font-mono font-bold"
                                />
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Room Inputs */}
                        {room.calcMode === 'dimensions' ? (
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                            <div>
                              <label className="block text-[10px] text-neutral-300 font-semibold mb-1">
                                Length ({unit === 'metric' ? 'm' : 'ft'})
                              </label>
                              <input
                                type="number"
                                step="0.1"
                                min="0.1"
                                value={room.length}
                                onChange={(e) =>
                                  handleUpdateRoom(room.id, 'length', parseFloat(e.target.value) || 0)
                                }
                                className="w-full h-9 px-2.5 bg-[#183242] border border-[#ead654]/30 rounded text-xs text-white font-mono font-bold focus:outline-none focus:border-[#ead654]"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-neutral-300 font-semibold mb-1">
                                Width ({unit === 'metric' ? 'm' : 'ft'})
                              </label>
                              <input
                                type="number"
                                step="0.1"
                                min="0.1"
                                value={room.width}
                                onChange={(e) =>
                                  handleUpdateRoom(room.id, 'width', parseFloat(e.target.value) || 0)
                                }
                                className="w-full h-9 px-2.5 bg-[#183242] border border-[#ead654]/30 rounded text-xs text-white font-mono font-bold focus:outline-none focus:border-[#ead654]"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-[#ead654] font-semibold mb-1">
                                Wastage Buffer
                              </label>
                              <select
                                value={room.wastagePct}
                                onChange={(e) =>
                                  handleUpdateRoom(room.id, 'wastagePct', parseInt(e.target.value) || 0)
                                }
                                className="w-full h-9 px-2 bg-[#183242] border border-[#ead654]/30 rounded text-xs text-white font-mono font-bold focus:outline-none focus:border-[#ead654]"
                              >
                                <option value={5}>5% Buffer</option>
                                <option value={10}>10% Standard</option>
                                <option value={15}>15% Diagonal</option>
                                <option value={20}>20% Complex</option>
                              </select>
                            </div>
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                            <div>
                              <label className="block text-[10px] text-neutral-300 font-semibold mb-1">
                                Direct Area ({unit === 'metric' ? 'm²' : 'sq ft'})
                              </label>
                              <input
                                type="number"
                                step="0.5"
                                min="0.1"
                                value={room.directArea}
                                onChange={(e) =>
                                  handleUpdateRoom(room.id, 'directArea', parseFloat(e.target.value) || 0)
                                }
                                className="w-full h-9 px-2.5 bg-[#183242] border border-[#ead654]/30 rounded text-xs text-white font-mono font-bold focus:outline-none focus:border-[#ead654]"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-[#ead654] font-semibold mb-1">
                                Wastage Buffer
                              </label>
                              <select
                                value={room.wastagePct}
                                onChange={(e) =>
                                  handleUpdateRoom(room.id, 'wastagePct', parseInt(e.target.value) || 0)
                                }
                                className="w-full h-9 px-2 bg-[#183242] border border-[#ead654]/30 rounded text-xs text-white font-mono font-bold focus:outline-none focus:border-[#ead654]"
                              >
                                <option value={5}>5% Buffer</option>
                                <option value={10}>10% Standard</option>
                                <option value={15}>15% Diagonal</option>
                                <option value={20}>20% Complex</option>
                              </select>
                            </div>
                          </div>
                        )}

                        {/* Include Wall Toggle */}
                        {room.calcMode === 'dimensions' && (
                          <div className="flex items-center justify-between text-xs pt-1">
                            <label className="flex items-center gap-2 cursor-pointer text-neutral-300 text-[11px]">
                              <input
                                type="checkbox"
                                checked={room.includeWalls}
                                onChange={(e) =>
                                  handleUpdateRoom(room.id, 'includeWalls', e.target.checked)
                                }
                                className="w-3.5 h-3.5 rounded accent-[#ead654]"
                              />
                              <span>Include Wall Tiling</span>
                            </label>
                            {room.includeWalls && (
                              <div className="flex items-center gap-1.5 text-[11px]">
                                <span className="text-neutral-400">Wall Height:</span>
                                <input
                                  type="number"
                                  step="0.1"
                                  min="0.5"
                                  value={room.wallHeight}
                                  onChange={(e) =>
                                    handleUpdateRoom(
                                      room.id,
                                      'wallHeight',
                                      parseFloat(e.target.value) || 0
                                    )
                                  }
                                  className="w-14 h-6 px-1.5 bg-[#183242] border border-[#ead654]/30 rounded text-white font-mono font-bold text-center"
                                />
                                <span className="text-[#ead654] font-mono">{unit === 'metric' ? 'm' : 'ft'}</span>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Room Mini Output Summary */}
                        {roomCalc && (
                          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono bg-[#183242]/80 px-3 py-2 rounded-lg border border-[#ead654]/20 text-neutral-300">
                            <span>
                              Format: <strong className="text-white">{roomCalc.widthCm}×{roomCalc.heightCm} cm</strong>
                            </span>
                            <span>
                              Factory: <strong className="text-[#ead654]">{roomCalc.factoryCode}</strong>
                            </span>
                            <span>
                              Net Area: <strong className="text-white">{roomCalc.netM2.toFixed(1)} m²</strong>
                            </span>
                            <span>
                              Gross (+{roomCalc.wastagePct}%): <strong className="text-[#ead654]">{roomCalc.grossM2.toFixed(1)} m²</strong>
                            </span>
                            <span>
                              Required: <strong className="text-[#ead654]">{roomCalc.exactBoxes} boxes</strong> ({roomCalc.exactTiles} pcs)
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Add Room Button */}
                <button
                  onClick={handleAddRoom}
                  className="w-full py-2.5 px-3 bg-[#0c1922] border border-dashed border-[#ead654]/40 hover:border-[#ead654] text-[#ead654] hover:text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Plus size={15} />
                  <span>Add Another Room / Area</span>
                </button>
              </div>

              {/* COMBINED GRAND TOTALS CARD */}
              <div className="p-4 bg-gradient-to-br from-[#0c1922] to-[#142937] rounded-2xl border-2 border-[#ead654]/50 shadow-xl space-y-4">
                <div className="flex justify-between items-center border-b border-[#ead654]/25 pb-2.5">
                  <span className="text-xs font-mono uppercase text-[#ead654] font-extrabold tracking-wider flex items-center gap-1.5">
                    <Sparkles size={14} /> Grand Project Material Summary ({rooms.length} {rooms.length === 1 ? 'Room' : 'Rooms'})
                  </span>
                  <span className="text-[10px] font-mono text-neutral-300">
                    Official URL: <strong className="text-[#ead654]">nirvanaport.com</strong>
                  </span>
                </div>

                {/* Primary Numbers Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div className="bg-[#183242]/90 p-2.5 rounded-xl border border-[#ead654]/20">
                    <span className="text-[10px] font-mono uppercase text-neutral-400 block font-semibold">Total Net Area</span>
                    <span className="text-base sm:text-lg font-mono font-extrabold text-white">
                      {roomCalculations.grandNetAreaM2.toFixed(1)} <span className="text-xs text-[#ead654]">m²</span>
                    </span>
                    <span className="text-[10px] font-mono text-neutral-400 block">
                      ({roomCalculations.grandNetAreaSqFt.toFixed(0)} sq ft)
                    </span>
                  </div>

                  <div className="bg-[#183242]/90 p-2.5 rounded-xl border border-[#ead654]/20">
                    <span className="text-[10px] font-mono uppercase text-neutral-400 block font-semibold">Gross Incl. Wastage</span>
                    <span className="text-base sm:text-lg font-mono font-extrabold text-[#ead654]">
                      {roomCalculations.grandGrossAreaM2.toFixed(1)} <span className="text-xs text-[#ead654]">m²</span>
                    </span>
                    <span className="text-[10px] font-mono text-neutral-400 block">
                      ({roomCalculations.grandGrossAreaSqFt.toFixed(0)} sq ft)
                    </span>
                  </div>

                  <div className="bg-[#183242]/90 p-2.5 rounded-xl border border-[#ead654]/20">
                    <span className="text-[10px] font-mono uppercase text-neutral-400 block font-semibold">Total Tiles</span>
                    <span className="text-base sm:text-lg font-mono font-extrabold text-white">
                      {roomCalculations.grandExactTiles} <span className="text-xs text-[#ead654]">pcs</span>
                    </span>
                    <span className="text-[10px] font-mono text-neutral-400 block">
                      (Across all rooms)
                    </span>
                  </div>

                  <div className="bg-[#183242]/90 p-2.5 rounded-xl border border-[#ead654]/30 shadow-md">
                    <span className="text-[10px] font-mono uppercase text-[#ead654] block font-extrabold">Full Boxes Needed</span>
                    <span className="text-lg sm:text-xl font-mono font-extrabold text-[#ead654]">
                      {roomCalculations.grandExactBoxes} <span className="text-xs text-white">boxes</span>
                    </span>
                    <span className="text-[10px] font-mono text-neutral-300 block">
                      ({roomCalculations.grandSuppliedM2.toFixed(2)} m² supplied)
                    </span>
                  </div>
                </div>

                {/* Weight & Link Footer */}
                <div className="flex flex-wrap items-center justify-between text-[11px] font-mono text-neutral-300 pt-1 px-1 border-t border-[#ead654]/15 gap-2">
                  <span className="flex items-center gap-1.5 text-neutral-300">
                    <Scale size={13} className="text-[#ead654]" /> Total Freight Weight:
                  </span>
                  <span className="text-[#ead654] font-bold">
                    ~{roomCalculations.grandWeightKg} kg ({roomCalculations.grandWeightLbs} lbs)
                  </span>
                </div>
              </div>

            </div>

            {/* Modal Actions Footer */}
            <div className="p-3.5 sm:p-4 bg-[#183242] border-t border-[#ead654]/30 shrink-0 flex flex-col sm:flex-row gap-2.5">
              <button
                onClick={() => setShowCertificateModal(true)}
                className="w-full sm:w-1/2 py-3 px-4 rounded-xl bg-[#142937] border border-[#ead654] hover:bg-[#1c384c] text-white font-sans text-xs sm:text-sm font-extrabold transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95 shadow-md"
              >
                <FileText size={18} className="text-[#ead654] shrink-0" />
                <span>Export Report</span>
              </button>

              <button
                onClick={handleApplyToForm}
                className="w-full sm:w-1/2 py-3 px-4 rounded-xl bg-[#ead654] hover:bg-[#f3e371] text-[#183242] font-sans text-xs sm:text-sm font-extrabold uppercase tracking-wider transition-all shadow-lg cursor-pointer flex items-center justify-center gap-2 active:scale-95"
              >
                <Sparkles size={18} className="shrink-0" />
                <span>Request Sample</span>
              </button>
            </div>
          </motion.div>

          {/* CUSTOM SIZING INFO MODAL */}
          <AnimatePresence>
            {showCustomInfo && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="bg-[#183242] border-2 border-[#ead654] rounded-2xl p-5 max-w-md w-full text-white shadow-2xl relative space-y-4"
                >
                  <div className="flex justify-between items-center border-b border-[#ead654]/30 pb-2">
                    <h4 className="font-bold text-sm text-[#ead654] flex items-center gap-2">
                      <Info size={16} /> Custom Size Calculation Specification
                    </h4>
                    <button
                      onClick={() => setShowCustomInfo(false)}
                      className="p-1 rounded bg-black/30 hover:bg-black/60 text-neutral-300"
                    >
                      <X size={14} />
                    </button>
                  </div>

                  <div className="space-y-2.5 text-xs text-neutral-200">
                    <p>
                      <strong>1. Volumetric Area Formula:</strong> Single tile area is calculated as{' '}
                      <code className="text-[#ead654] font-mono">(Width cm × Height cm) / 10,000</code> in square meters (m²).
                    </p>
                    <p>
                      <strong>2. Carton Packaging Rate:</strong> Box coverage equals{' '}
                      <code className="text-[#ead654] font-mono">Single Tile Area × Pieces Per Box</code>. If custom pcs/box is left at default, standard factory carton capacities apply.
                    </p>
                    <p>
                      <strong>3. Factory Density Weights:</strong> Freight weight is determined by your selected factory&apos;s physical density rating (19.8 kg/m² to 22.5 kg/m²).
                    </p>
                    <p>
                      <strong>4. Wastage Allowance:</strong> Standard +5% to +20% buffers auto-scale based on room cut pattern requirements.
                    </p>
                  </div>

                  <button
                    onClick={() => setShowCustomInfo(false)}
                    className="w-full py-2 bg-[#ead654] text-[#183242] font-extrabold rounded-xl text-xs uppercase"
                  >
                    Got It
                  </button>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* OFFICIAL SPECIFICATION REPORT MODAL */}
          <AnimatePresence>
            {showCertificateModal && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md">
                <motion.div
                  initial={{ opacity: 0, scale: 0.92 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.92 }}
                  className="bg-[#183242] border-2 border-[#ead654] rounded-2xl p-4 sm:p-6 max-w-2xl w-full text-white shadow-2xl relative space-y-4 max-h-[90vh] overflow-y-auto custom-scrollbar"
                >
                  <div className="flex justify-between items-start border-b border-[#ead654]/30 pb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[#ead654] text-[#183242] flex items-center justify-center font-black">
                        <FileText size={24} />
                      </div>
                      <div>
                        <span className="text-[10px] font-mono tracking-widest text-[#ead654] uppercase font-bold block">
                          NIRVANA ARCHITECTURAL REPORT
                        </span>
                        <h4 className="font-bold text-lg text-white">
                          Official Specification & Calculation Report
                        </h4>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowCertificateModal(false)}
                      className="p-1.5 rounded-full bg-black/40 hover:bg-black/70 text-neutral-300"
                    >
                      <X size={16} />
                    </button>
                  </div>

                  {/* Report Document Preview Box */}
                  <div className="p-4 bg-[#0c1922] border border-[#ead654]/40 rounded-xl space-y-4 relative overflow-hidden">
                    {/* Watermark Overlay */}
                    <div className="absolute inset-0 pointer-events-none opacity-5 flex items-center justify-center select-none rotate-[-15deg] text-[#ead654] font-mono text-2xl font-black tracking-widest text-center leading-relaxed">
                      OFFICIAL NIRVANA SPECIFICATION<br/>NIRVANAPORT.COM ESTIMATE
                    </div>

                    <div className="flex justify-between items-center text-xs font-mono text-[#ead654]">
                      <span>REPORT REF: NIR-REP-{(Math.floor(100000 + Math.random() * 900000))}</span>
                      <span>URL: nirvanaport.com</span>
                    </div>

                    {preselectedTileName && (
                      <div className="text-xs font-semibold text-white border-b border-[#ead654]/15 pb-2">
                        Product: <span className="text-[#ead654] font-bold">{preselectedTileName}</span>
                      </div>
                    )}

                    {/* Table of rooms */}
                    <div className="space-y-2 text-xs font-mono">
                      <div className="grid grid-cols-4 font-bold text-[#ead654] border-b border-[#ead654]/20 pb-1 text-[11px]">
                        <span>Room</span>
                        <span>Format / Factory</span>
                        <span>Net Surface</span>
                        <span>Boxes Req.</span>
                      </div>
                      {roomCalculations.details.map((r, i) => (
                        <div key={i} className="grid grid-cols-4 text-neutral-200 border-b border-white/5 pb-1 text-[11px]">
                          <span>{r.name}</span>
                          <span>{r.widthCm}×{r.heightCm} cm ({r.factoryCode})</span>
                          <span>{r.netM2.toFixed(1)} m²</span>
                          <span className="text-[#ead654] font-bold">{r.exactBoxes} boxes</span>
                        </div>
                      ))}
                    </div>

                    {/* Totals */}
                    <div className="pt-2 border-t border-[#ead654]/30 flex flex-wrap justify-between items-center text-xs font-mono">
                      <div>
                        Total Net: <strong className="text-white">{roomCalculations.grandNetAreaM2.toFixed(2)} m²</strong>
                      </div>
                      <div>
                        Full Material: <strong className="text-[#ead654]">{roomCalculations.grandExactBoxes} Boxes ({roomCalculations.grandSuppliedM2.toFixed(2)} m²)</strong>
                      </div>
                      <div>
                        Freight: <strong className="text-[#ead654]">~{roomCalculations.grandWeightKg} kg</strong>
                      </div>
                    </div>

                    {/* Estimation Disclaimer Box */}
                    <div className="bg-[#142937]/90 p-3 rounded-lg border border-[#ead654]/30 text-xs text-neutral-200 space-y-1">
                      <div className="text-[11px] font-mono text-[#ead654] font-bold flex items-center gap-1.5">
                        <Info size={14} /> Estimation & Planning Notice:
                      </div>
                      <p className="text-[11px] leading-relaxed text-neutral-300">
                        Note: All figures shown are approximate estimates for initial architectural planning. Approximately transportation to border is about $400 and the Customs cost about $150. If you want to know exact numbers, please contact us.
                      </p>
                    </div>

                    {/* Stamp & QR Code */}
                    <div className="flex justify-between items-center pt-2 border-t border-white/10 text-[10px] text-neutral-400">
                      <div className="flex items-center gap-3 text-[#ead654]">
                        <div className="w-12 h-12 bg-white p-1 rounded-md flex items-center justify-center shrink-0 border border-[#ead654]/50">
                          <img
                            src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=https://nirvanaport.com"
                            alt="nirvanaport.com QR Code"
                            className="w-full h-full object-contain"
                            onError={(e) => {
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                          <QrCode size={24} className="text-[#183242] hidden" />
                        </div>
                        <div>
                          <span className="text-white font-bold block text-xs">nirvanaport.com</span>
                          <span>Scan QR code to visit official catalog</span>
                        </div>
                      </div>
                      <div className="border border-[#ead654] px-2.5 py-1.5 rounded-lg text-[#ead654] font-mono font-bold uppercase tracking-wider text-[9px] bg-[#183242]">
                        NIRVANA SPECIFICATION STAMP
                      </div>
                    </div>
                  </div>

                  {/* Actions - PNG Download Only */}
                  <div className="pt-2">
                    <button
                      onClick={handleDownloadPNG}
                      className="w-full py-3 bg-[#ead654] hover:bg-[#f3e371] text-[#183242] font-extrabold rounded-xl text-xs sm:text-sm uppercase flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-95 transition-all"
                    >
                      <Download size={17} />
                      <span>Download</span>
                    </button>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>
        </div>
      )}
    </AnimatePresence>
  );
}

