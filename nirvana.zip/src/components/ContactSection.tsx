import React, { useState, FormEvent, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Copy, Check, Send, Sparkles, Box, MapPin, Phone, Mail, ExternalLink, MessageCircle, SendHorizontal, X, Plus } from 'lucide-react';

interface Props {
  preselectedTileSample?: string;
}

export default function ContactSection({ preselectedTileSample }: Props) {
  const [copied, setCopied] = useState(false);
  const [currentSample, setCurrentSample] = useState<string>(preselectedTileSample || '');

  useEffect(() => {
    if (preselectedTileSample) {
      setCurrentSample(preselectedTileSample);
    }
  }, [preselectedTileSample]);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    concept: '',
  });

  const [selectedServices, setSelectedServices] = useState<string[]>(
    preselectedTileSample ? ['Sample Kit'] : ['Wholesale Trade Order']
  );
  
  const [isCustomTopicActive, setIsCustomTopicActive] = useState(false);
  const [customTopicInput, setCustomTopicInput] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const baseServices = ['Sample Kit', 'Wholesale Trade Order', 'Custom Slab Specification', 'Showroom Visit'];

  const copyEmail = (emailStr: string) => {
    navigator.clipboard.writeText(emailStr);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleServiceToggle = (service: string) => {
    setSelectedServices(prev => 
      prev.includes(service) ? prev.filter(s => s !== service) : [...prev, service]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.concept) return;
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', phone: '', company: '', concept: '' });
      setSelectedServices([]);
      setIsCustomTopicActive(false);
      setCustomTopicInput('');
      setCurrentSample('');
    }, 4000);
  };

  return (
    <div className="w-full h-full flex flex-col justify-between p-4 sm:p-6 md:p-8 max-w-5xl mx-auto overflow-y-auto max-h-[82vh] sm:max-h-[84vh] pb-32 sm:pb-36 custom-scrollbar pointer-events-auto select-text text-white">
      <div>
        {/* Section Header */}
        <div className="flex items-center gap-2 mb-4">
          <span className="w-2 h-2 rounded-full bg-[#ead654] animate-pulse" />
          <span className="text-[10px] sm:text-xs font-mono tracking-widest text-[#ead654] uppercase font-bold">
            CONTACTS & DIRECT CHANNELS
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10">
          
          {/* Left Column: Contact Channels & Office Locations */}
          <div className="lg:col-span-5 space-y-4 sm:space-y-5">
            <div className="space-y-2">
              <h2 className="text-2xl sm:text-4xl md:text-5xl text-white font-bold leading-tight tracking-tight">
                Get in touch with <span className="text-[#ead654]">Nirvana</span>.
              </h2>
              <p className="text-neutral-200 text-xs sm:text-sm leading-relaxed font-normal">
                Direct phone lines, WhatsApp, Telegram, email, and showroom visits in Yazd, Iran and internationally.
              </p>
            </div>

            {/* Quick Action Channels: WhatsApp & Telegram */}
            <div className="grid grid-cols-2 gap-3">
              <a
                href="https://wa.me/989130000000?text=Hello%20Nirvana%20Team,%20I%20would%20like%20to%20inquire%20about%20stone%20samples."
                target="_blank"
                rel="noreferrer"
                className="p-3 bg-[#12232f]/90 hover:bg-[#ead654] text-white hover:text-[#183242] border border-[#ead654]/40 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer font-bold text-xs shadow-lg backdrop-blur-md group"
              >
                <MessageCircle size={16} className="text-[#ead654] group-hover:text-[#183242]" />
                <span>WhatsApp Desk</span>
              </a>

              <a
                href="https://t.me/NirvanaTiles"
                target="_blank"
                rel="noreferrer"
                className="p-3 bg-[#12232f]/90 hover:bg-[#ead654] text-white hover:text-[#183242] border border-[#ead654]/40 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer font-bold text-xs shadow-lg backdrop-blur-md group"
              >
                <SendHorizontal size={16} className="text-[#ead654] group-hover:text-[#183242]" />
                <span>Telegram Desk</span>
              </a>
            </div>

            {/* Phone & Email Info Card */}
            <div className="p-4 sm:p-5 bg-[#12232f]/90 border border-[#ead654]/30 rounded-xl space-y-3 backdrop-blur-md shadow-xl">
              <div>
                <span className="text-[10px] font-mono tracking-widest text-[#ead654] uppercase font-bold block mb-1">
                  Direct Phone Lines
                </span>
                <div className="space-y-1.5 text-xs sm:text-sm">
                  <div className="flex items-center gap-2 text-neutral-100">
                    <Phone size={14} className="text-[#ead654]" />
                    <span>Yazd Central Office: <strong>+98 35 3820 0000</strong></span>
                  </div>
                  <div className="flex items-center gap-2 text-neutral-100">
                    <Phone size={14} className="text-[#ead654]" />
                    <span>International Desk: <strong>+98 913 000 0000</strong></span>
                  </div>
                </div>
              </div>

              <div className="border-t border-[#ead654]/20 pt-2.5">
                <span className="text-[10px] font-mono tracking-widest text-[#ead654] uppercase font-bold block mb-1">
                  Email Desk
                </span>
                <div className="flex items-center justify-between gap-2 text-xs sm:text-sm">
                  <div className="flex items-center gap-2 text-neutral-100 font-medium">
                    <Mail size={14} className="text-[#ead654]" />
                    <span>trade@nirvana.com</span>
                  </div>
                  <button
                    onClick={() => copyEmail('trade@nirvana.com')}
                    className="p-1.5 rounded bg-[#0c1922] hover:bg-[#ead654] text-neutral-200 hover:text-[#183242] transition-colors cursor-pointer"
                    title="Copy Email"
                  >
                    {copied ? <Check size={13} className="text-[#ead654]" /> : <Copy size={13} />}
                  </button>
                </div>
              </div>
            </div>

            {/* Office Address & Location */}
            <div className="p-4 sm:p-5 bg-[#12232f]/90 border border-[#ead654]/30 rounded-xl space-y-2 text-xs sm:text-sm backdrop-blur-md shadow-xl">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-[10px] font-mono text-[#ead654] uppercase font-bold flex items-center gap-1">
                    <MapPin size={12} /> Office & Showroom Location
                  </span>
                  <a 
                    href="https://maps.google.com/?q=Yazd,+Iran" 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-[11px] font-mono text-[#ead654] hover:underline flex items-center gap-1 font-semibold"
                  >
                    <span>Google Maps</span>
                    <ExternalLink size={10} />
                  </a>
                </div>
                <p className="text-neutral-100 font-semibold">Boulevard Jomhouri, Industrial Zone, Yazd, Iran</p>
                <p className="text-neutral-300 text-xs mt-0.5">Yazd Tile & Stone Commerce Center, Yazd, Iran</p>
              </div>
            </div>
          </div>

          {/* Right Column: Sample Request & Trade Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="bg-[#12232f]/90 border border-[#ead654]/30 rounded-2xl p-5 sm:p-7 shadow-2xl backdrop-blur-md">
              
              <AnimatePresence mode="wait">
                {isSubmitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex flex-col items-center justify-center py-10 text-center"
                  >
                    <div className="w-12 h-12 rounded-full bg-[#ead654]/20 border border-[#ead654] flex items-center justify-center text-[#ead654] mb-3 animate-bounce">
                      <Sparkles size={20} />
                    </div>
                    <h4 className="text-xl font-bold text-white">Inquiry Received</h4>
                    <p className="text-neutral-200 text-xs sm:text-sm mt-2 max-w-[320px] leading-relaxed">
                      Thank you. Our team will contact you via WhatsApp or Email within 24 hours.
                    </p>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    
                    <div className="flex justify-between items-center border-b border-[#ead654]/20 pb-2">
                      <h3 className="text-lg sm:text-xl font-bold text-white">Send Direct Message</h3>
                      <span className="text-[10px] font-mono text-[#ead654] uppercase font-bold">24hr Response</span>
                    </div>

                    {/* Preselected Sample Pill */}
                    {currentSample && (
                      <div className="p-2.5 bg-[#0c1922] border border-[#ead654]/40 rounded-lg text-xs text-[#ead654] flex items-center justify-between gap-2 shadow-sm">
                        <div className="flex items-center gap-2 font-medium">
                          <Box size={14} />
                          <span>Preselected Sample: <strong>{currentSample}</strong></span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setCurrentSample('')}
                          className="p-1 rounded hover:bg-[#ead654]/20 text-[#ead654] hover:text-white transition-colors cursor-pointer"
                          title="Remove preselected sample"
                          aria-label="Remove preselected sample"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    )}

                    {/* Name & Email */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-widest text-[#ead654] mb-1 font-bold">
                          Your Name
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          placeholder="e.g. Alex Vance"
                          className="w-full h-10 px-3 bg-[#0c1922] border border-[#ead654]/40 rounded-lg text-xs sm:text-sm text-white focus:outline-none focus:border-[#ead654] transition-all placeholder:text-neutral-400 font-medium"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-widest text-[#ead654] mb-1 font-bold">
                          Email Address
                        </label>
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="e.g. alex@architects.com"
                          className="w-full h-10 px-3 bg-[#0c1922] border border-[#ead654]/40 rounded-lg text-xs sm:text-sm text-white focus:outline-none focus:border-[#ead654] transition-all placeholder:text-neutral-400 font-medium"
                        />
                      </div>
                    </div>

                    {/* Phone & Company */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-widest text-[#ead654] mb-1 font-bold">
                          Phone / WhatsApp Number
                        </label>
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          placeholder="e.g. +48 500 123 456"
                          className="w-full h-10 px-3 bg-[#0c1922] border border-[#ead654]/40 rounded-lg text-xs sm:text-sm text-white focus:outline-none focus:border-[#ead654] transition-all placeholder:text-neutral-400 font-medium"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-widest text-[#ead654] mb-1 font-bold">
                          Company / Firm (Optional)
                        </label>
                        <input
                          type="text"
                          value={formData.company}
                          onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                          placeholder="e.g. Studio Vance Architecture"
                          className="w-full h-10 px-3 bg-[#0c1922] border border-[#ead654]/40 rounded-lg text-xs sm:text-sm text-white focus:outline-none focus:border-[#ead654] transition-all placeholder:text-neutral-400 font-medium"
                        />
                      </div>
                    </div>

                    {/* Service Type Selection */}
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-mono uppercase tracking-widest text-[#ead654] font-bold">
                        Inquiry Topic
                      </label>
                      <div className="flex flex-wrap gap-1.5">
                        {baseServices.map(service => {
                          const active = selectedServices.includes(service);
                          return (
                            <button
                              key={service}
                              type="button"
                              onClick={() => handleServiceToggle(service)}
                              className={`h-7 px-3 rounded-full text-[11px] font-bold transition-all cursor-pointer ${
                                active 
                                  ? 'bg-[#ead654] text-[#183242] shadow-md' 
                                  : 'bg-[#0c1922] border border-[#ead654]/30 hover:border-[#ead654] text-neutral-200'
                              }`}
                            >
                              {service}
                            </button>
                          );
                        })}

                        {/* Custom Topic Toggle */}
                        <button
                          type="button"
                          onClick={() => setIsCustomTopicActive(!isCustomTopicActive)}
                          className={`h-7 px-3 rounded-full text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
                            isCustomTopicActive || customTopicInput
                              ? 'bg-[#ead654] text-[#183242] shadow-md'
                              : 'bg-[#0c1922] border border-[#ead654]/30 hover:border-[#ead654] text-neutral-200'
                          }`}
                        >
                          <Plus size={12} />
                          <span>Custom Topic</span>
                        </button>
                      </div>

                      {/* Custom Topic Input */}
                      {isCustomTopicActive && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="pt-1"
                        >
                          <input
                            type="text"
                            value={customTopicInput}
                            onChange={(e) => setCustomTopicInput(e.target.value)}
                            placeholder="Type your custom inquiry topic..."
                            className="w-full h-9 px-3 bg-[#0c1922] border border-[#ead654]/40 rounded-lg text-xs sm:text-sm text-white focus:outline-none focus:border-[#ead654] transition-all placeholder:text-neutral-400 font-medium"
                          />
                        </motion.div>
                      )}
                    </div>

                    {/* Message / Details */}
                    <div>
                      <label className="block text-[10px] font-mono uppercase tracking-widest text-[#ead654] mb-1 font-bold">
                        Project Scope / Details
                      </label>
                      <textarea
                        required
                        rows={2}
                        value={formData.concept}
                        onChange={(e) => setFormData({ ...formData, concept: e.target.value })}
                        placeholder="Provide details regarding project timeline, quantities, or sample delivery address..."
                        className="w-full p-2.5 bg-[#0c1922] border border-[#ead654]/40 rounded-lg text-xs sm:text-sm text-white focus:outline-none focus:border-[#ead654] transition-all placeholder:text-neutral-400 resize-none leading-relaxed font-medium"
                      />
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      className="w-full h-11 bg-[#ead654] hover:bg-[#f3e371] text-[#183242] rounded-lg text-xs font-extrabold uppercase tracking-wider transition-all shadow-xl cursor-pointer flex items-center justify-center gap-2 hover:scale-[1.01]"
                    >
                      <Send size={14} className="text-[#183242]" />
                      <span>Transmit Inquiry</span>
                    </button>

                  </form>
                )}
              </AnimatePresence>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
