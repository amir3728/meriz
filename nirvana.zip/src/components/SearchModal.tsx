import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, ArrowRight, Grid, BookOpen, Home, Check, Filter } from 'lucide-react';
import { PageId, SearchResult } from '../types';
import { TileData } from '../data/tileData';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSelectPage: (page: PageId) => void;
  onSelectTile?: (tileId: string) => void;
  onSelectBlogPost?: (postId: string) => void;
}

export default function SearchModal({
  isOpen,
  onClose,
  onSelectPage,
  onSelectTile,
  onSelectBlogPost,
}: Props) {
  const [query, setQuery] = useState('');

  const allPages: SearchResult[] = [
    {
      id: 'page-home',
      type: 'page',
      title: 'Home Page',
      category: 'Landing & 3D Landscape',
      description: 'The 3D stone landscape experience with glowing lunar spheres and brand philosophy.',
      pageId: 'home',
    },
    {
      id: 'page-about',
      type: 'page',
      title: 'About Us',
      category: 'Philosophy, Logistics & Stats',
      description: 'What we do, supply chain certainty, country statistics, quarry verification and logistics services in Yazd, Iran.',
      pageId: 'about',
    },
    {
      id: 'page-gallery',
      type: 'page',
      title: 'Tile & Stone Gallery',
      category: 'Velvet 60×60 & Architectural Slabs',
      description: 'Flagship Velvet porcelain, Calacatta marble, Terrazzo, red body, white body, 60x60, 30x60, and sintered slabs.',
      pageId: 'gallery',
    },
    {
      id: 'page-blog',
      type: 'page',
      title: 'Architectural Blog',
      category: 'Insights & Technical Spec Guides',
      description: 'Supply chain certainty, short-notice inventory, freight dispatch and Velvet porcelain specifications.',
      pageId: 'blog',
    },
    {
      id: 'page-contact',
      type: 'page',
      title: 'Contacts & Office Location',
      category: 'Office, Maps, WhatsApp & Direct Email',
      description: 'Get in touch with office address in Yazd Iran, Google location map, Telegram, WhatsApp, and email.',
      pageId: 'contact',
    },
  ];

  const normalizeForSearch = (str: string) => {
    if (!str) return '';
    let norm = str
      .toLowerCase()
      .replace(/×/g, 'x')
      .replace(/&/g, 'and')
      .replace(/\s+/g, ' ');

    // Automatically expand dimension patterns like "60 x 60" or "60x60" to include "60x60 6060"
    norm = norm.replace(/(\d+)\s*x\s*(\d+)/g, (match, p1, p2) => {
      return `${p1}x${p2} ${p1}${p2}`;
    });

    return norm;
  };

  const getWordVariants = (word: string): string[] => {
    const norm = word.toLowerCase().replace(/×/g, 'x');
    const variants = [norm];

    // If word is pure digits between 4 and 6 characters long (e.g., 6060, 3060, 12060, 120120)
    if (/^\d{4,6}$/.test(norm)) {
      if (norm.length === 4) {
        // 6060 -> 60x60, 3060 -> 30x60, 8080 -> 80x80
        variants.push(`${norm.slice(0, 2)}x${norm.slice(2)}`);
      } else if (norm.length === 5) {
        // 12060 -> 120x60, 60120 -> 60x120
        variants.push(`${norm.slice(0, 3)}x${norm.slice(3)}`);
        variants.push(`${norm.slice(0, 2)}x${norm.slice(2)}`);
      } else if (norm.length === 6) {
        // 120120 -> 120x120, 120280 -> 120x280
        variants.push(`${norm.slice(0, 3)}x${norm.slice(3)}`);
      }
    } else if (/^\d+\s*x\s*\d+$/.test(norm)) {
      // If word is "60x60", also add "6060"
      const compact = norm.replace(/\s*x\s*/g, '');
      variants.push(compact);
    }

    return variants;
  };

  const tileResults: SearchResult[] = useMemo(
    () =>
      TileData.tiles.map((tile) => ({
        id: tile.id,
        type: 'tile',
        title: tile.name,
        category: `Tile — ${tile.category} (${tile.glazeFinish || tile.finish}) • ${tile.dimensions}`,
        description: `${tile.description} ${tile.dimensions} ${tile.sizeCategory} ${tile.body} ${tile.glazeFinish || ''} ${tile.origin} ${tile.features.join(' ')} ${tile.recommendedUse}`,
        pageId: 'gallery',
      })),
    []
  );

  const blogResults: SearchResult[] = useMemo(
    () =>
      TileData.blogPosts.map((post) => ({
        id: post.id,
        type: 'blog',
        title: post.title,
        category: `Blog — ${post.category}`,
        description: `${post.excerpt} ${post.author} ${post.content}`,
        pageId: 'blog',
      })),
    []
  );

  const allSearchItems = useMemo(
    () => [...allPages, ...tileResults, ...blogResults],
    [allPages, tileResults, blogResults]
  );

  // Multi-clause search supporting comma-separated terms (OR logic between comma clauses, AND within each clause)
  const filtered = useMemo(() => {
    const trimmed = query.trim();
    if (!trimmed) return allSearchItems.slice(0, 8);

    // Split by comma to support queries like "6060, 3060, Porcelain"
    const clauses = trimmed
      .split(',')
      .map((c) => c.trim())
      .filter((c) => c.length > 0);

    if (clauses.length === 0) return allSearchItems.slice(0, 8);

    return allSearchItems.filter((item) => {
      const titleNorm = normalizeForSearch(item.title);
      const catNorm = normalizeForSearch(item.category);
      const descNorm = normalizeForSearch(item.description);
      const fullTextNorm = `${titleNorm} ${catNorm} ${descNorm}`;

      const titleCompact = titleNorm.replace(/\s+/g, '');
      const catCompact = catNorm.replace(/\s+/g, '');
      const descCompact = descNorm.replace(/\s+/g, '');
      const fullTextCompact = `${titleCompact}${catCompact}${descCompact}`;

      // An item passes if it matches AT LEAST ONE comma clause
      return clauses.some((clause) => {
        const clauseNorm = normalizeForSearch(clause);
        const clauseWords = clauseNorm
          .replace(/[^a-z0-9x]/gi, ' ')
          .split(/\s+/)
          .filter((w) => w.length > 0);

        const clauseCompact = clauseNorm.replace(/\s+/g, '');

        if (clauseWords.length > 0) {
          const allWordsMatch = clauseWords.every((word) => {
            const variants = getWordVariants(word);
            return variants.some((v) => fullTextNorm.includes(v) || fullTextCompact.includes(v));
          });
          if (allWordsMatch) return true;
        }

        if (clauseCompact.length >= 3 && fullTextCompact.includes(clauseCompact)) {
          return true;
        }

        return false;
      });
    });
  }, [query, allSearchItems]);

  // Quick Filters toggle handler
  const handleTagToggle = (tag: string) => {
    const currentTags = query
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    const tagNorm = tag.trim().toLowerCase();
    const existsIndex = currentTags.findIndex(
      (t) => t.toLowerCase() === tagNorm
    );

    let updatedTags: string[];
    if (existsIndex >= 0) {
      updatedTags = currentTags.filter((_, idx) => idx !== existsIndex);
    } else {
      updatedTags = [...currentTags, tag.trim()];
    }

    setQuery(updatedTags.join(', '));
  };

  const isTagActive = (tag: string) => {
    const currentTags = query
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter((t) => t.length > 0);
    return currentTags.includes(tag.trim().toLowerCase());
  };

  const handleResultClick = (item: SearchResult) => {
    onSelectPage(item.pageId);
    if (item.type === 'tile' && onSelectTile) {
      onSelectTile(item.id);
    } else if (item.type === 'blog' && onSelectBlogPost) {
      onSelectBlogPost(item.id);
    }
    onClose();
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'page':
        return <Home size={14} className="text-[#ead654]" />;
      case 'tile':
        return <Grid size={14} className="text-[#ead654]" />;
      case 'blog':
        return <BookOpen size={14} className="text-sky-300" />;
      default:
        return <Search size={14} className="text-[#ead654]" />;
    }
  };

  const quickFilterTags = ['6060', '3060', 'Velvet', 'Porcelain', 'Yazd Iran', 'Logistics'];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/85 backdrop-blur-md cursor-pointer"
          />

          {/* Search Box */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: -20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 280 }}
            className="relative w-[92%] sm:w-full max-w-2xl bg-[#183242] border border-[#ead654]/40 rounded-2xl sm:rounded-3xl p-3.5 sm:p-6 text-white shadow-2xl z-10 my-auto max-h-[82vh] sm:max-h-[85vh] flex flex-col overflow-hidden pointer-events-auto"
          >
            {/* Input Bar */}
            <div className="relative flex items-center mb-3 sm:mb-4 shrink-0">
              <Search className="absolute left-3.5 text-[#ead654]" size={18} />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search e.g., 6060, 3060, Velvet, Porcelain..."
                className="w-full h-11 sm:h-12 pl-10 sm:pl-12 pr-16 bg-[#0c1922] border border-[#ead654]/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-[#ead654] focus:ring-1 focus:ring-[#ead654]/50 transition-all placeholder:text-neutral-400 font-medium"
              />
              {query && (
                <button
                  onClick={() => setQuery('')}
                  className="absolute right-10 text-neutral-400 hover:text-[#ead654] transition-colors p-1 cursor-pointer text-xs font-mono"
                  aria-label="Clear query"
                >
                  Clear
                </button>
              )}
              <button
                onClick={onClose}
                className="absolute right-3.5 text-neutral-400 hover:text-[#ead654] transition-colors p-1 cursor-pointer"
                aria-label="Close search"
              >
                <X size={18} />
              </button>
            </div>

            {/* Quick Filters Multi-Select */}
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 mb-4 shrink-0 bg-[#0c1922]/60 p-2 sm:p-2.5 rounded-xl border border-[#ead654]/20">
              <span className="text-[10px] font-mono uppercase text-[#ead654] font-bold flex items-center gap-1">
                <Filter size={11} /> Filters:
              </span>
              {quickFilterTags.map((tag) => {
                const active = isTagActive(tag);
                return (
                  <motion.button
                    key={tag}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleTagToggle(tag)}
                    className={`px-2.5 py-1 rounded-full border text-[10px] sm:text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1 ${
                      active
                        ? 'bg-[#ead654] text-[#183242] border-[#ead654] shadow-md font-extrabold'
                        : 'bg-[#183242] hover:bg-[#1f4258] text-neutral-200 border-[#ead654]/30'
                    }`}
                  >
                    {active && <Check size={11} className="stroke-[3]" />}
                    <span>{tag}</span>
                  </motion.button>
                );
              })}
            </div>

            {/* Hint Notice */}
            <div className="mb-3 text-[10px] font-mono text-neutral-400 flex items-center justify-between">
              <span>Combine tags or separate terms with commas (e.g. <code>6060, 3060, Porcelain</code>)</span>
              {query && (
                <span className="text-[#ead654] font-bold">
                  {filtered.length} found
                </span>
              )}
            </div>

            {/* Results List */}
            <div className="max-h-72 sm:max-h-80 overflow-y-auto space-y-2 pr-1 custom-scrollbar shrink">
              {filtered.length > 0 ? (
                filtered.map((item) => (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    onClick={() => handleResultClick(item)}
                    className="p-3 sm:p-3.5 rounded-xl bg-[#0c1922]/80 hover:bg-[#0c1922] border border-[#ead654]/20 hover:border-[#ead654]/60 transition-all cursor-pointer flex items-center justify-between group active:scale-[0.99]"
                  >
                    <div className="flex items-start gap-2.5">
                      <div className="mt-0.5 p-1.5 sm:p-2 rounded-lg bg-[#183242] border border-[#ead654]/30 shrink-0">
                        {getTypeIcon(item.type)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-sans text-sm sm:text-base font-semibold text-white group-hover:text-[#ead654] transition-colors">
                            {item.title}
                          </h4>
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#183242] text-[#ead654] font-semibold border border-[#ead654]/20">
                            {item.category}
                          </span>
                        </div>
                        <p className="text-xs text-neutral-300 mt-0.5 line-clamp-1">
                          {item.description}
                        </p>
                      </div>
                    </div>
                    <ArrowRight size={15} className="text-[#ead654]/60 group-hover:text-[#ead654] group-hover:translate-x-1 transition-all shrink-0 ml-2" />
                  </motion.div>
                ))
              ) : (
                <div className="py-12 text-center text-neutral-400 text-xs font-mono space-y-1">
                  <p>No results found for "{query}".</p>
                  <p className="text-[10px] text-neutral-500">Try searching for "6060, 3060", "Velvet", or "Porcelain".</p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="mt-3 pt-3 border-t border-[#ead654]/20 flex justify-between items-center text-[10px] font-mono text-neutral-400 shrink-0">
              <span className="text-[#ead654] font-bold">{filtered.length} matching items</span>
              <span>Select result to navigate immediately</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}


