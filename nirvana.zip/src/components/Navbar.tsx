import React from 'react';
import { Search, Calculator } from 'lucide-react';
import { PageId } from '../types';
import AudioController from './AudioController';

interface Props {
  onSelectPage: (page: PageId) => void;
  onOpenSearch: () => void;
  onOpenCalculator: () => void;
}

export default function Navbar({ onSelectPage, onOpenSearch, onOpenCalculator }: Props) {
  return (
    <header className="fixed top-0 left-0 w-full px-4 sm:px-8 pt-4 sm:pt-6 pb-3 flex justify-between items-center z-30 pointer-events-none select-none">
      
      {/* Brand SVG Logotype - Top Left */}
      <div 
        onClick={() => onSelectPage('home')}
        className="pointer-events-auto cursor-pointer group flex items-center gap-2"
        aria-label="Nirvana Home"
      >
        <img 
          src="/assets/Logo/Logo.svg" 
          alt="Nirvana" 
          className="h-7 sm:h-9 object-contain drop-shadow-[0_0_12px_rgba(234,214,84,0.35)] group-hover:scale-105 transition-transform"
        />
      </div>

      {/* Top Right Controls: Ambient Audio, Tile Calculator & Search */}
      <nav className="flex items-center gap-2 sm:gap-2.5 pointer-events-auto">
        <AudioController />

        <button
          onClick={onOpenCalculator}
          className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#183242]/90 hover:bg-[#183242] border border-[#ead654]/40 text-[#ead654] hover:scale-105 flex items-center justify-center transition-all cursor-pointer shadow-lg backdrop-blur-md active:scale-95"
          title="Stone & Tile Requirements Calculator"
          aria-label="Stone & Tile Requirements Calculator"
        >
          <Calculator size={16} />
        </button>

        <button
          onClick={onOpenSearch}
          className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#183242]/90 hover:bg-[#183242] border border-[#ead654]/40 text-[#ead654] hover:scale-105 flex items-center justify-center transition-all cursor-pointer shadow-lg backdrop-blur-md active:scale-95"
          title="Search Tiles & Specs"
          aria-label="Search Tiles & Specs"
        >
          <Search size={16} />
        </button>
      </nav>

    </header>
  );
}

