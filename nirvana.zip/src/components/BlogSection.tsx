import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Clock, User, ArrowLeft, ArrowUpRight, Share2, Check, ChevronUp } from 'lucide-react';
import { BlogPost } from '../types';
import { TileData } from '../data/tileData';

interface Props {
  targetPostId?: string | null;
}

export default function BlogSection({ targetPostId }: Props) {
  const [activeArticle, setActiveArticle] = useState<BlogPost | null>(null);
  const [copied, setCopied] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    if (targetPostId) {
      const post = TileData.blogPosts.find((p) => p.id === targetPostId);
      if (post) {
        setActiveArticle(post);
      }
    }
  }, [targetPostId]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const handleScroll = () => {
      setShowScrollTop(el.scrollTop > 180);
    };
    el.addEventListener('scroll', handleScroll);
    return () => el.removeEventListener('scroll', handleScroll);
  }, []);

  const handleScrollToTop = () => {
    if (containerRef.current) {
      containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      ref={containerRef}
      className="w-full h-full flex flex-col justify-between p-4 sm:p-6 md:p-10 max-w-5xl mx-auto overflow-y-auto max-h-[82vh] sm:max-h-[84vh] pb-32 sm:pb-36 custom-scrollbar pointer-events-auto text-white relative"
    >
      <AnimatePresence mode="wait">
        {activeArticle ? (
          /* Full Article Reader View */
          <motion.div
            key="article-reader"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6 select-text text-white"
          >
            <button
              onClick={() => setActiveArticle(null)}
              className="flex items-center gap-2 text-xs font-mono text-[#ead654] hover:underline cursor-pointer py-1"
            >
              <ArrowLeft size={14} /> Back to all articles
            </button>

            <div className="space-y-3 border-b border-[#ead654]/25 pb-6">
              <div className="flex flex-wrap items-center gap-3 text-[10px] font-mono text-neutral-300">
                <span className="px-2.5 py-0.5 rounded-full bg-[#ead654] text-[#183242] font-bold uppercase">
                  {activeArticle.category}
                </span>
                <span>{activeArticle.date}</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock size={11} /> {activeArticle.readTime}
                </span>
              </div>

              <h2 className="font-serif text-3xl md:text-5xl text-white font-normal leading-tight">
                {activeArticle.title}
              </h2>

              <div className="flex justify-between items-center text-xs text-neutral-300 pt-2">
                <span className="flex items-center gap-1.5 font-mono text-[#ead654]">
                  <User size={13} /> {activeArticle.author}
                </span>
                <button
                  onClick={handleShare}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#183242] border border-[#ead654]/40 text-white hover:text-[#ead654] text-[11px] cursor-pointer"
                >
                  {copied ? <Check size={12} className="text-[#ead654]" /> : <Share2 size={12} />}
                  <span>{copied ? 'Link Copied' : 'Share Article'}</span>
                </button>
              </div>
            </div>

            {/* Content Paragraphs */}
            <div className="space-y-5 text-neutral-200 text-sm md:text-base leading-relaxed font-light py-2 max-w-3xl">
              {activeArticle.content.map((paragraph, i) => (
                <p key={i}>{paragraph}</p>
              ))}
            </div>

            {/* Tags */}
            <div className="pt-6 border-t border-[#ead654]/25 flex flex-wrap gap-2">
              {activeArticle.tags.map((tag) => (
                <span key={tag} className="text-[10px] font-mono px-2.5 py-1 rounded bg-[#183242] border border-[#ead654]/30 text-[#ead654]">
                  #{tag}
                </span>
              ))}
            </div>
          </motion.div>
        ) : (
          /* Article Index List */
          <motion.div
            key="article-list"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-6"
          >
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="w-2 h-2 rounded-full bg-[#ead654] animate-pulse" />
                <span className="text-[10px] font-mono tracking-widest text-[#ead654] uppercase font-semibold">
                  ARCHITECTURAL JOURNAL & ARTICLES
                </span>
              </div>
              <h2 className="font-serif text-3xl md:text-5xl text-white font-normal tracking-tight">
                Supply Strategy & Spec Insights
              </h2>
              <p className="text-neutral-300 text-xs md:text-sm mt-2 max-w-2xl font-light leading-relaxed">
                Articles on short-notice tile supply line management, Velvet 60×60 porcelain performance, and eliminating inventory risk.
              </p>
            </div>

            {/* Blog Post List */}
            <div className="space-y-4 my-4">
              {TileData.blogPosts.map((post) => (
                <div
                  key={post.id}
                  onClick={() => setActiveArticle(post)}
                  className="group bg-[#183242]/80 border border-[#ead654]/30 rounded-2xl p-5 md:p-6 hover:border-[#ead654] transition-all duration-300 cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-5"
                >
                  <div className="space-y-2 max-w-2xl">
                    <div className="flex items-center gap-3 text-[10px] font-mono text-neutral-300">
                      <span className="text-[#ead654] font-bold uppercase">{post.category}</span>
                      <span>•</span>
                      <span>{post.date}</span>
                      <span>•</span>
                      <span>{post.readTime}</span>
                    </div>

                    <h3 className="font-serif text-xl md:text-2xl text-white font-normal group-hover:text-[#ead654] transition-colors">
                      {post.title}
                    </h3>

                    <p className="text-xs text-neutral-300 line-clamp-2 font-light leading-relaxed">
                      {post.excerpt}
                    </p>
                  </div>

                  <div className="shrink-0 flex items-center gap-2 text-xs font-mono text-[#ead654] group-hover:translate-x-1 transition-transform">
                    <span>Read Article</span>
                    <ArrowUpRight size={15} />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FLOATING SCROLL TO TOP BUTTON */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={handleScrollToTop}
            className="fixed bottom-14 sm:bottom-16 right-4 sm:right-8 z-40 p-3 rounded-full bg-[#183242] border-2 border-[#ead654] text-[#ead654] hover:bg-[#ead654] hover:text-[#183242] shadow-2xl transition-all cursor-pointer flex items-center justify-center group active:scale-95"
            title="Scroll to Top"
            aria-label="Scroll to Top"
          >
            <ChevronUp size={20} className="group-hover:-translate-y-0.5 transition-transform" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}

