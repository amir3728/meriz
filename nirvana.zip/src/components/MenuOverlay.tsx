import { motion, AnimatePresence } from 'motion/react';
import { Home, Info, Grid, BookOpen, Mail, Search, Calculator, X } from 'lucide-react';
import { PageId } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  activePage: PageId;
  onSelectPage: (page: PageId) => void;
  onOpenSearch: () => void;
  onOpenCalculator: () => void;
}

export default function MenuOverlay({
  isOpen,
  onClose,
  activePage,
  onSelectPage,
  onOpenSearch,
  onOpenCalculator,
}: Props) {
  const menuItems = [
    {
      id: 'home' as PageId,
      label: 'Home',
      sublabel: 'Landing & 3D Scene',
      icon: Home,
      action: () => {
        onSelectPage('home');
        onClose();
      },
    },
    {
      id: 'about' as PageId,
      label: 'About Us',
      sublabel: 'Philosophy & Logistics',
      icon: Info,
      action: () => {
        onSelectPage('about');
        onClose();
      },
    },
    {
      id: 'gallery' as PageId,
      label: 'Gallery',
      sublabel: 'Velvet 60×60 & Slabs',
      icon: Grid,
      action: () => {
        onSelectPage('gallery');
        onClose();
      },
    },
    {
      id: 'calculator',
      label: 'Tile Calculator',
      sublabel: 'Estimate Quantities',
      icon: Calculator,
      action: () => {
        onClose();
        onOpenCalculator();
      },
    },
    {
      id: 'blog' as PageId,
      label: 'Blog',
      sublabel: 'Supply Strategy',
      icon: BookOpen,
      action: () => {
        onSelectPage('blog');
        onClose();
      },
    },
    {
      id: 'contact' as PageId,
      label: 'Contacts',
      sublabel: 'Office & Inquiries',
      icon: Mail,
      action: () => {
        onSelectPage('contact');
        onClose();
      },
    },
    {
      id: 'search',
      label: 'Search',
      sublabel: 'Products & Specs',
      icon: Search,
      action: () => {
        onClose();
        onOpenSearch();
      },
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 select-none pointer-events-auto">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-md cursor-pointer"
          />

          {/* Compact Menu Card without scrollbar */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 10 }}
            transition={{ type: 'spring', damping: 26, stiffness: 300 }}
            className="relative w-full max-w-xl bg-[#183242] border border-[#ead654]/40 rounded-2xl sm:rounded-3xl p-4 sm:p-6 text-white shadow-2xl z-10 my-auto overflow-hidden flex flex-col"
          >
            {/* Subtle glow effect */}
            <div className="absolute -top-16 -left-16 w-48 h-48 bg-[#ead654]/15 rounded-full blur-2xl pointer-events-none" />
            
            {/* Header */}
            <div className="flex justify-between items-center mb-3 sm:mb-5 border-b border-[#ead654]/20 pb-2.5 sm:pb-3 shrink-0">
              <div className="flex items-center gap-2">
                <img src="/assets/Logo/Logo.svg" alt="Nirvana" className="h-6 sm:h-7 object-contain" />
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-black/40 hover:bg-black/60 text-[#ead654] flex items-center justify-center transition-all cursor-pointer border border-[#ead654]/30 active:scale-95"
                aria-label="Close menu"
              >
                <X size={18} />
              </button>
            </div>

            {/* Menu Items Grid: 2 columns, compact fixed layout without scrollbar */}
            <div className="grid grid-cols-2 gap-2 sm:gap-3">
              {menuItems.map((item, idx) => {
                const IconComponent = item.icon;
                const isActive = item.id === activePage;

                return (
                  <motion.button
                    key={item.label}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.02 }}
                    onClick={item.action}
                    className={`group relative p-2.5 sm:p-4 rounded-xl border text-left transition-all duration-150 cursor-pointer flex flex-col justify-between active:scale-[0.98] ${
                      isActive
                        ? 'bg-[#ead654] border-[#ead654] text-[#183242] shadow-md'
                        : 'bg-[#0c1922]/90 hover:bg-[#0c1922] border-[#ead654]/25 hover:border-[#ead654]/60 text-white'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <div
                        className={`w-7 h-7 sm:w-9 sm:h-9 rounded-lg flex items-center justify-center transition-all ${
                          isActive
                            ? 'bg-[#183242] text-[#ead654]'
                            : 'bg-[#183242] text-[#ead654] group-hover:bg-[#ead654] group-hover:text-[#183242]'
                        }`}
                      >
                        <IconComponent size={15} className="sm:w-4 sm:h-4" />
                      </div>
                      <span className={`text-[9px] font-mono font-extrabold ${isActive ? 'text-[#183242]/70' : 'text-neutral-400'}`}>
                        0{idx + 1}
                      </span>
                    </div>

                    <div className="mt-1.5 sm:mt-2">
                      <h4 className={`font-sans text-xs sm:text-sm md:text-base font-bold tracking-tight ${isActive ? 'text-[#183242]' : 'text-white group-hover:text-[#ead654]'} transition-colors`}>
                        {item.label}
                      </h4>
                      <p className={`text-[9px] sm:text-[10px] font-sans mt-0.5 line-clamp-1 ${isActive ? 'text-[#183242]/80' : 'text-neutral-400'}`}>
                        {item.sublabel}
                      </p>
                    </div>

                    {/* Active highlight indicator */}
                    {isActive && (
                      <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-[#183242]" />
                    )}
                  </motion.button>
                );
              })}
            </div>

            {/* Compact Footer */}
            <div className="mt-3 sm:mt-4 pt-2 border-t border-[#ead654]/20 flex justify-between items-center text-[9px] sm:text-[10px] font-mono text-neutral-400 shrink-0">
              <span className="text-[#ead654] font-bold">Nirvana Navigation</span>
              <span>Tap to switch view</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
