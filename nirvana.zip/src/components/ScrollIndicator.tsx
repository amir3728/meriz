import React from 'react';
import { motion } from 'motion/react';
import { Grid, Menu } from 'lucide-react';
import { PageId } from '../types';

interface Props {
  activePage: PageId;
  onToggleMenu: () => void;
  isMenuOpen: boolean;
}

export default function ScrollIndicator({ activePage, onToggleMenu, isMenuOpen }: Props) {
  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 flex flex-col items-center gap-1.5 select-none pointer-events-none">
      
      {/* Circle Ring containing 'R' or Menu icon */}
      <button
        id="menu-trigger-r-btn"
        onClick={onToggleMenu}
        className={`w-11 h-11 rounded-full border border-white/30 bg-black/60 backdrop-blur-md flex items-center justify-center pointer-events-auto transition-all duration-300 hover:scale-110 cursor-pointer shadow-xl group border-emerald-500/40 hover:border-emerald-400 ${
          isMenuOpen ? 'ring-2 ring-emerald-400 bg-emerald-950' : ''
        }`}
        aria-label="Open page navigation menu"
        title="Click to open menu (6 pages & search)"
      >
        <span className="font-serif italic text-white text-base font-medium group-hover:text-emerald-200 transition-colors">
          R
        </span>
      </button>

      {/* Label 'menu' */}
      <span className="text-[9px] font-mono tracking-widest text-emerald-300/80 uppercase font-medium bg-black/40 px-2 py-0.5 rounded-full backdrop-blur-sm border border-white/5">
        Menu
      </span>
      
    </div>
  );
}
