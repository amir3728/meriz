export type PageId = 'home' | 'about' | 'gallery' | 'blog' | 'contact';

export type TileBody = 'White Body' | 'Red Body';
export type GlazeFinish = 'Matte' | 'Glazed';

export interface TileItem {
  id: string;
  name: string;
  category: 'Porcelain' | 'Marble' | 'Terrazzo' | 'Ceramic & Mosaic' | 'Large Format Slabs';
  body: TileBody;
  glazeFinish: GlazeFinish;
  origin: string;
  finish: 'Matte' | 'Glazed';
  dimensions: string;
  sizeCategory: string;
  thickness: string;
  description: string;
  colorHex: string;
  images: string[];
  features: string[];
  recommendedUse: string;
}

export interface BlogPost {
  id: string;
  title: string;
  category: string;
  date: string;
  readTime: string;
  author: string;
  excerpt: string;
  content: string[];
  tags: string[];
}

export interface SearchResult {
  id: string;
  type: 'page' | 'tile' | 'blog';
  title: string;
  category: string;
  description: string;
  pageId: PageId;
}

export interface StatMetric {
  id: string;
  value: string;
  label: string;
  subtext: string;
}
