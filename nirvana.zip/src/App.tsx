import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PageId } from './types';
import AudioController from './components/AudioController';
import Navbar from './components/Navbar';
import AboutSection from './components/AboutSection';
import GallerySection from './components/GallerySection';
import BlogSection from './components/BlogSection';
import ContactSection from './components/ContactSection';
import MenuOverlay from './components/MenuOverlay';
import SearchModal from './components/SearchModal';
import CalculatorModal from './components/CalculatorModal';
import { ArrowRight } from 'lucide-react';

export default function App() {
  const [activePage, setActivePage] = useState<PageId>('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isTileModalOpen, setIsTileModalOpen] = useState(false);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [calculatorTileName, setCalculatorTileName] = useState<string>('');
  const [preselectedTileSample, setPreselectedTileSample] = useState<string>('');
  const [targetTileId, setTargetTileId] = useState<string | null>(null);
  const [targetPostId, setTargetPostId] = useState<string | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [loadingPercent, setLoadingPercent] = useState(0);

  // Fast preloader
  useEffect(() => {
    let count = 0;
    const interval = setInterval(() => {
      count += Math.floor(Math.random() * 10) + 5;
      if (count >= 100) {
        count = 100;
        clearInterval(interval);
        setTimeout(() => {
          setIsLoading(false);
        }, 200);
      }
      setLoadingPercent(count);
    }, 20);

    return () => clearInterval(interval);
  }, []);

  const handleRequestSample = (tileName: string) => {
    setPreselectedTileSample(tileName);
    setIsTileModalOpen(false);
    setActivePage('contact');
  };

  const handleOpenCalculator = (tileName?: string) => {
    if (tileName) {
      setCalculatorTileName(tileName);
    } else {
      setCalculatorTileName('');
    }
    setIsCalculatorOpen(true);
  };

  const handleApplyCalculationToQuote = (calculationText: string) => {
    setPreselectedTileSample(calculationText);
    setActivePage('contact');
  };

  useEffect(() => {
    setIsTileModalOpen(false);
  }, [activePage]);

  return (
    <main className="fixed inset-0 w-screen h-screen bg-[#0b161f] overflow-hidden select-none selection:bg-[#ead654] selection:text-[#183242]">
      
      {/* 1. FAST PRELOADER */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.35, ease: 'easeInOut' } }}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0a131a] text-white"
          >
            <div className="space-y-4 text-center px-4">
              <motion.img
                src="/assets/Logo/Logo.svg"
                alt="Nirvana"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
                className="h-10 sm:h-12 md:h-14 mx-auto object-contain drop-shadow-[0_0_18px_rgba(234,214,84,0.5)]"
              />

              <div className="h-0.5 w-32 bg-[#183242] mx-auto relative overflow-hidden rounded-full">
                <motion.div 
                  className="absolute left-0 top-0 h-full bg-[#ead654]"
                  style={{ width: `${loadingPercent}%` }}
                />
              </div>

              <div className="text-[10px] font-mono tracking-widest text-neutral-400 uppercase">
                {loadingPercent.toString().padStart(3, '0')} % Loaded
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. DYNAMIC DEDICATED BACKGROUND MEDIA PER PAGE */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden bg-[#0b161f]">
        <AnimatePresence mode="wait">
          {activePage === 'home' && (
            <motion.div
              key="bg-home-container"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="absolute inset-0 w-full h-full"
            >
              <video
                src="/assets/BG%20Home.mp4"
                autoPlay
                loop
                muted
                playsInline
                preload="auto"
                className="w-full h-full object-cover"
              />
            </motion.div>
          )}

          {activePage === 'about' && (
            <motion.div
              key="bg-about-container"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="absolute inset-0 w-full h-full"
            >
              <video
                src="/assets/BG%201.mp4"
                autoPlay
                loop
                muted
                playsInline
                preload="auto"
                className="w-full h-full object-cover"
              />
            </motion.div>
          )}

          {activePage === 'gallery' && (
            <motion.div
              key="bg-gallery-container"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="absolute inset-0 w-full h-full"
            >
              <video
                src="/assets/BG%202.mp4"
                autoPlay
                loop
                muted
                playsInline
                preload="auto"
                className="w-full h-full object-cover"
              />
            </motion.div>
          )}

          {(activePage === 'blog' || activePage === 'contact') && (
            <motion.div
              key={activePage === 'blog' ? 'bg-blog-container' : 'bg-contact-container'}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="absolute inset-0 w-full h-full"
            >
              <img
                src="/assets/BG%203.png"
                alt="Background Surface"
                className="w-full h-full object-cover"
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Ambient Dark Overlay to Ensure Crystal Clear High Contrast Text */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a131a] via-[#0b161f]/75 to-[#0a131a]/60 z-10" />
      </div>

      {/* 3. TOP NAVBAR */}
      <Navbar
        onSelectPage={setActivePage}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenCalculator={() => handleOpenCalculator()}
      />

      {/* 4. OVERLAY MENU */}
      <MenuOverlay
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        activePage={activePage}
        onSelectPage={setActivePage}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenCalculator={() => handleOpenCalculator()}
      />

      {/* 5. GLOBAL SEARCH MODAL */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectPage={setActivePage}
        onSelectTile={(tileId) => setTargetTileId(tileId)}
        onSelectBlogPost={(postId) => setTargetPostId(postId)}
      />

      {/* 6. PROJECT TILE CALCULATOR MODAL */}
      <CalculatorModal
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
        onApplyToQuote={handleApplyCalculationToQuote}
        preselectedTileName={calculatorTileName}
      />

      {/* 7. FLOATING BOTTOM-CENTERED MENU BUTTON (3 HORIZONTAL LINES ICON) - HIDE WHEN OVERLAY/SEARCH/MODAL/CALCULATOR IS OPEN */}
      {!isMenuOpen && !isSearchOpen && !isTileModalOpen && !isCalculatorOpen && (
        <div className="fixed bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 z-40 pointer-events-auto">
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsMenuOpen(true)}
            className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-[#ead654] hover:bg-[#f3e371] text-[#183242] flex items-center justify-center shadow-2xl shadow-[#ead654]/30 cursor-pointer border-2 border-[#ead654] group transition-all"
            title="Open Navigation Menu"
            aria-label="Open Navigation Menu"
          >
            {/* 3 Horizontal Lines Menu Icon */}
            <div className="flex flex-col gap-1 items-center justify-center">
              <span className="w-4 sm:w-5 h-[2.5px] bg-[#183242] rounded-full group-hover:w-6 transition-all duration-300" />
              <span className="w-4 sm:w-5 h-[2.5px] bg-[#183242] rounded-full" />
              <span className="w-4 sm:w-5 h-[2.5px] bg-[#183242] rounded-full group-hover:w-6 transition-all duration-300" />
            </div>
          </motion.button>
        </div>
      )}

      {/* 8. SINGLE-SCREEN VIEW CONTAINER */}
      <div className="relative z-20 w-full h-full pt-16 sm:pt-20 pb-16 sm:pb-20 flex items-center justify-center">
        <AnimatePresence mode="wait">
          
          {/* PAGE 1: HOME */}
          {activePage === 'home' && (
            <motion.div
              key="home-page"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="w-full max-w-4xl px-4 sm:px-6 text-center select-none"
            >
              <div className="space-y-6 sm:space-y-8 bg-[#0b161f]/70 backdrop-blur-md p-6 sm:p-12 rounded-2xl sm:rounded-3xl border border-[#ead654]/30 shadow-2xl">
                
                {/* Core Statement in Contemporary Font */}
                <h1 className="font-sans text-lg sm:text-2xl md:text-4xl text-white font-normal leading-relaxed sm:leading-snug md:leading-normal tracking-tight max-w-3xl mx-auto text-balance">
                  From inventory validation to delivery follow-through, we help your projects move with <span className="font-semibold text-[#ead654] drop-shadow-[0_0_12px_rgba(234,214,84,0.4)]">clarity, confidence</span>, and less risk.
                </h1>

                {/* Primary Action Button */}
                <div className="pt-2 flex justify-center items-center gap-4">
                  <button
                    onClick={() => setActivePage('gallery')}
                    className="h-11 sm:h-12 px-7 sm:px-9 rounded-full bg-[#ead654] hover:bg-[#f3e371] text-[#183242] text-xs sm:text-sm font-sans font-bold uppercase tracking-wider transition-all shadow-xl shadow-[#ead654]/25 cursor-pointer flex items-center gap-2 hover:scale-105"
                  >
                    <span>Explore Collections</span>
                    <ArrowRight size={16} />
                  </button>
                </div>

              </div>
            </motion.div>
          )}

          {/* PAGE 2: ABOUT US */}
          {activePage === 'about' && (
            <motion.div
              key="about-page"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
              className="w-full h-full flex items-center justify-center"
            >
              <AboutSection onSelectPage={setActivePage} />
            </motion.div>
          )}

          {/* PAGE 3: GALLERY */}
          {activePage === 'gallery' && (
            <motion.div
              key="gallery-page"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
              className="w-full h-full flex items-center justify-center"
            >
              <GallerySection 
                onRequestSampleModal={handleRequestSample}
                onModalToggle={setIsTileModalOpen}
                onOpenCalculator={handleOpenCalculator}
                targetTileId={targetTileId}
              />
            </motion.div>
          )}

          {/* PAGE 4: BLOG */}
          {activePage === 'blog' && (
            <motion.div
              key="blog-page"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
              className="w-full h-full flex items-center justify-center"
            >
              <BlogSection targetPostId={targetPostId} />
            </motion.div>
          )}

          {/* PAGE 5: CONTACTS */}
          {activePage === 'contact' && (
            <motion.div
              key="contact-page"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
              className="w-full h-full flex items-center justify-center"
            >
              <ContactSection preselectedTileSample={preselectedTileSample} />
            </motion.div>
          )}

        </AnimatePresence>
      </div>

      {/* FOOTER BAR */}
      <footer className="fixed bottom-0 left-0 w-full z-30 px-4 sm:px-6 py-2 sm:py-2.5 flex justify-between items-center text-[10px] font-mono text-neutral-300 bg-[#0a131a]/90 backdrop-blur-md border-t border-[#ead654]/15 pointer-events-none">
        <span className="text-[#ead654]">© {new Date().getFullYear()} Nirvana</span>
        <span className="hidden sm:inline">Warsaw • Singapore</span>
      </footer>

    </main>
  );
}
