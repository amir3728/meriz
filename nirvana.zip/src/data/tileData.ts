import { TileItem, BlogPost, StatMetric } from '../types';

export class TileData {
  static tiles: TileItem[] = [
    {
      id: 'velvet-porcelain-60x60',
      name: 'Velvet Soft Porcelain 60×60',
      category: 'Porcelain',
      body: 'White Body',
      glazeFinish: 'Matte',
      origin: 'Castellón, Spain & Milan, Italy',
      finish: 'Matte',
      dimensions: '60 × 60 cm',
      sizeCategory: '60×60 cm',
      thickness: '10 mm',
      description: 'Velvet is our flagship architectural series designed specifically for luxury bathrooms, wet rooms, and high-performance kitchens. Offers a silky micro-honed touch with R10 slip safety.',
      colorHex: '#183242',
      images: [
        '/assets/Gallery/Velvet/Velvet Render.png',
        '/assets/Gallery/Velvet/Velvet Tex.png',
        '/assets/Stock Images/pietra-gray-daltile-porcelain-tile-ar70rct1224pl-e4_600.jpg'
      ],
      features: [
        'Optimized for Bath & Kitchen Wet Areas',
        'Silky tactile texture with anti-slip micro-surface',
        'Zero water absorption (< 0.05%)',
        'Stain resistant & chemical proof'
      ],
      recommendedUse: 'Bathroom floors & walls, kitchen backsplashes, shower enclosures, residential flooring'
    },
    {
      id: 'velvet-studio-porcelain-30x60',
      name: 'Velvet Studio White Body 30×60',
      category: 'Porcelain',
      body: 'White Body',
      glazeFinish: 'Matte',
      origin: 'Castellón, Spain',
      finish: 'Matte',
      dimensions: '30 × 60 cm',
      sizeCategory: '30×60 cm',
      thickness: '9.5 mm',
      description: 'Compact 30×60 architectural format designed for versatile brick-bond wall layouts, shower surrounds, and high-performance bathroom floors.',
      colorHex: '#183242',
      images: [
        '/assets/Gallery/Velvet/Velvet Tex.png',
        '/assets/Gallery/Velvet/Velvet Render.png',
        '/assets/Stock Images/pietra-gray-daltile-porcelain-tile-ar70rct1224pl-e4_600.jpg'
      ],
      features: [
        'Versatile 30×60 cm proportions for brick or stack layouts',
        'Silky micro-honed touch with R10 slip safety',
        'Impervious water resistance (< 0.05%)',
        'Ideal for bath wet walls & kitchen backsplashes'
      ],
      recommendedUse: 'Bathroom walls & floors, kitchen splashbacks, shower enclosures'
    },
    {
      id: 'linear-stone-white-body-30x60',
      name: 'Linear Satin White Body 30×60',
      category: 'Ceramic & Mosaic',
      body: 'White Body',
      glazeFinish: 'Glazed',
      origin: 'Valencia, Spain',
      finish: 'Glazed',
      dimensions: '30 × 60 cm',
      sizeCategory: '30×60 cm',
      thickness: '9 mm',
      description: 'Refined 30×60 white body ceramic wall tile featuring delicate linear texture and soft satin glaze reflectivity.',
      colorHex: '#e8e4dc',
      images: [
        '/assets/Stock Images/download (2).png',
        '/assets/Stock Images/download (3).png'
      ],
      features: ['Precision white body clay matrix', 'Satin tactile glaze', 'Rectified seamless edges'],
      recommendedUse: 'Hotel bath walls, luxury kitchen backsplashes, feature accents'
    },
    {
      id: 'cotto-artisan-red-body-30x60',
      name: 'Artisan Terra Red Body 30×60',
      category: 'Ceramic & Mosaic',
      body: 'Red Body',
      glazeFinish: 'Glazed',
      origin: 'Seville, Spain',
      finish: 'Glazed',
      dimensions: '30 × 60 cm',
      sizeCategory: '30×60 cm',
      thickness: '8.5 mm',
      description: 'Earthy 30×60 red body ceramic tile with warm terracotta glaze undertones and durable protective gloss coating.',
      colorHex: '#c26b52',
      images: [
        '/assets/Stock Images/download (4).png',
        '/assets/Stock Images/download (5).png'
      ],
      features: ['Warm Mediterranean aesthetic', 'Cost-effective architectural wall format', 'Stain resistant surface'],
      recommendedUse: 'Kitchen walls, dining accents, bistro backdrops'
    },
    {
      id: 'calacatta-gold-slabs',
      name: 'Calacatta Oro Luxe White Body 60×60',
      category: 'Porcelain',
      body: 'White Body',
      glazeFinish: 'Glazed',
      origin: 'Carrara, Italy',
      finish: 'Glazed',
      dimensions: '60 × 60 cm',
      sizeCategory: '60×60 cm',
      thickness: '10 mm',
      description: 'Prestige white body tile featuring dramatic amber and warm grey veins on a luminescent field.',
      colorHex: '#f4f1ea',
      images: [
        '/assets/Stock Images/download.png',
        '/assets/Stock Images/download (1).png'
      ],
      features: ['Luminous white body backing', 'Glazed reflective finish', 'Precision diamond-rectified edge'],
      recommendedUse: 'High-end interior walls, luxury bathrooms, feature walls'
    },
    {
      id: 'pietra-grey-porcelain',
      name: 'Pietra Slate Charcoal White Body 30×60',
      category: 'Porcelain',
      body: 'White Body',
      glazeFinish: 'Matte',
      origin: 'Castellón, Spain',
      finish: 'Matte',
      dimensions: '30 × 60 cm',
      sizeCategory: '30×60 cm',
      thickness: '10 mm',
      description: 'Sophisticated dark graphite white body tile with delicate white mineral veins.',
      colorHex: '#252a2e',
      images: [
        '/assets/Stock Images/pietra-gray-daltile-porcelain-tile-ar70rct1224pl-e4_600.jpg',
        '/assets/Stock Images/download (2).png'
      ],
      features: ['R10 Anti-Slip rating', 'Scratch resistant surface', 'Matte architectural feel'],
      recommendedUse: 'Bath wet walls, kitchen splashbacks, shower enclosures'
    },
    {
      id: 'nordic-stone-unglazed',
      name: 'Nordic Basalt Red Body 60×60',
      category: 'Porcelain',
      body: 'Red Body',
      glazeFinish: 'Matte',
      origin: 'Bologna, Italy',
      finish: 'Matte',
      dimensions: '60 × 60 cm',
      sizeCategory: '60×60 cm',
      thickness: '10 mm',
      description: 'Red body technical tile featuring authentic basalt volcanic grain in a clean matte finish.',
      colorHex: '#3a3f47',
      images: [
        '/assets/Stock Images/download (7).png',
        '/assets/Stock Images/surreal-geometric-shapes-barren-desert_23-2151296312.jpg'
      ],
      features: ['Red body clay matrix', 'Matte anti-reflective surface', 'Heavy traffic load capacity'],
      recommendedUse: 'Commercial floors, outdoor corridors, residential halls'
    },
    {
      id: 'carrara-white-body-wall',
      name: 'Carrara Statuario White Body 60×60',
      category: 'Ceramic & Mosaic',
      body: 'White Body',
      glazeFinish: 'Glazed',
      origin: 'Valencia, Spain',
      finish: 'Glazed',
      dimensions: '60 × 60 cm',
      sizeCategory: '60×60 cm',
      thickness: '9 mm',
      description: 'Ultra-refined white body ceramic tile with smooth glaze layer. Delivers crisp true white undertones for luminous bathroom feature walls.',
      colorHex: '#fbfbfb',
      images: [
        '/assets/Stock Images/download.png',
        '/assets/Stock Images/download (1).png'
      ],
      features: ['Ultra-white body clay matrix', 'High-luster glaze finish', 'Easy-clean surface'],
      recommendedUse: 'Luxury bathroom walls, vanity backdrops, hotel suites'
    },
    {
      id: 'alps-satin-white-body',
      name: 'Alabaster Satin White Body 30×60',
      category: 'Ceramic & Mosaic',
      body: 'White Body',
      glazeFinish: 'Glazed',
      origin: 'Castellón, Spain',
      finish: 'Glazed',
      dimensions: '30 × 60 cm',
      sizeCategory: '30×60 cm',
      thickness: '9.5 mm',
      description: 'Smooth glazed white body ceramic wall tile featuring soft satin sheen and subtle cloud movement.',
      colorHex: '#eeebe6',
      images: [
        '/assets/Stock Images/download (2).png',
        '/assets/Stock Images/download (3).png'
      ],
      features: ['Lightweight precision wall tile', 'High stain resistance', 'Seamless rectified joints'],
      recommendedUse: 'Kitchen backsplashes, shower walls, vertical panels'
    },
    {
      id: 'terracotta-raw-white-body',
      name: 'Artisan Biscuit White Body 30×60',
      category: 'Ceramic & Mosaic',
      body: 'White Body',
      glazeFinish: 'Matte',
      origin: 'Fez, Morocco',
      finish: 'Matte',
      dimensions: '30 × 60 cm',
      sizeCategory: '30×60 cm',
      thickness: '9.5 mm',
      description: 'Natural matte white clay tile crafted for tactile accent walls and Mediterranean architectural details.',
      colorHex: '#d8cbb5',
      images: [
        '/assets/Stock Images/download (5).png',
        '/assets/Stock Images/download (6).png'
      ],
      features: ['Tactile matte finish', 'Organic texture', 'Warm neutral palette'],
      recommendedUse: 'Restaurant accents, feature wall niche'
    },
    {
      id: 'cotto-clasico-red-body',
      name: 'Cotto Mediterranean Red Body 60×60',
      category: 'Ceramic & Mosaic',
      body: 'Red Body',
      glazeFinish: 'Glazed',
      origin: 'Seville, Spain',
      finish: 'Glazed',
      dimensions: '60 × 60 cm',
      sizeCategory: '60×60 cm',
      thickness: '8.5 mm',
      description: 'Rich traditional red body ceramic tile with vibrant glazed layer. Brings timeless warmth and character to residential spaces.',
      colorHex: '#b85d43',
      images: [
        '/assets/Stock Images/download (4).png',
        '/assets/Stock Images/download (5).png'
      ],
      features: ['Vibrant glaze color depth', 'Cost-effective high aesthetic value', 'Thermal shock resistant'],
      recommendedUse: 'Residential kitchens, dining walls, accent corridors'
    },
    {
      id: 'rustico-terracotta-red-body',
      name: 'Tuscan Cotto Red Body 60×60',
      category: 'Ceramic & Mosaic',
      body: 'Red Body',
      glazeFinish: 'Matte',
      origin: 'Tuscany, Italy',
      finish: 'Matte',
      dimensions: '60 × 60 cm',
      sizeCategory: '60×60 cm',
      thickness: '10 mm',
      description: 'Traditional matte red body tile with warm earthy undertones and natural textured feel.',
      colorHex: '#a04d36',
      images: [
        '/assets/Stock Images/download (6).png',
        '/assets/Stock Images/download (7).png'
      ],
      features: ['Earthy matte red body', 'Rustic character', 'Ideal for indoor/patio spaces'],
      recommendedUse: 'Patio spaces, rustic wine rooms, Mediterranean interiors'
    },
    {
      id: 'venetian-terrazzo-verde',
      name: 'Verde Alpi Terrazzo 60×60',
      category: 'Terrazzo',
      body: 'White Body',
      glazeFinish: 'Matte',
      origin: 'Treviso, Italy',
      finish: 'Matte',
      dimensions: '60 × 60 cm',
      sizeCategory: '60×60 cm',
      thickness: '10 mm',
      description: 'Sustainably crafted matte white body composite featuring deep emerald serpentine stone chips.',
      colorHex: '#183242',
      images: [
        '/assets/Stock Images/download (3).png',
        '/assets/Stock Images/download (4).png'
      ],
      features: ['Extreme durability', 'Matte tactile finish', 'Slip resistance R10'],
      recommendedUse: 'Boutique retail floors, hotel lobbies, high-traffic commercial spaces'
    },
    {
      id: 'zellige-emerald-mosaic',
      name: 'Handcrafted Zellige Red Body 30×60',
      category: 'Ceramic & Mosaic',
      body: 'Red Body',
      glazeFinish: 'Glazed',
      origin: 'Fez, Morocco',
      finish: 'Glazed',
      dimensions: '30 × 60 cm',
      sizeCategory: '30×60 cm',
      thickness: '9.5 mm',
      description: 'Artisanal red body clay tiles glazed with subtle organic variation in tone.',
      colorHex: '#ead654',
      images: [
        '/assets/Stock Images/download (5).png',
        '/assets/Stock Images/download (6).png'
      ],
      features: ['Handcrafted authenticity', 'Organic tonal depth', 'Heat-resistant glaze'],
      recommendedUse: 'Kitchen backsplashes, artisanal bar surrounds, wet rooms'
    },
    {
      id: 'emperador-dark-porcelain',
      name: 'Emperador Bronze White Body 60×60',
      category: 'Porcelain',
      body: 'White Body',
      glazeFinish: 'Glazed',
      origin: 'Modena, Italy',
      finish: 'Glazed',
      dimensions: '60 × 60 cm',
      sizeCategory: '60×60 cm',
      thickness: '10 mm',
      description: 'Deep espresso white body tile with liquid amber crystal veining and reflective glazed coating.',
      colorHex: '#2e231d',
      images: [
        '/assets/Stock Images/download (1).png',
        '/assets/Stock Images/download (2).png'
      ],
      features: ['Deep reflective glaze', 'Resistant to thermal shock', 'Rectified zero-grout edge'],
      recommendedUse: 'Hotel reception halls, penthouse living rooms, luxury lobbies'
    },
    {
      id: 'travertino-navona-porcelain',
      name: 'Travertino Navona Red Body 60×60',
      category: 'Porcelain',
      body: 'Red Body',
      glazeFinish: 'Matte',
      origin: 'Tivoli, Italy',
      finish: 'Matte',
      dimensions: '60 × 60 cm',
      sizeCategory: '60×60 cm',
      thickness: '10 mm',
      description: 'Warm cream travertine pattern captured in durable matte red body tile with soft tactile finish.',
      colorHex: '#dfd4be',
      images: [
        '/assets/Stock Images/download (3).png',
        '/assets/Stock Images/download (4).png'
      ],
      features: ['Linear vein-cut design', 'Micro-structured non-slip matte finish', 'Stain immune'],
      recommendedUse: 'Villa main floors, pool surrounds, outdoor terraces'
    },
    {
      id: 'statuary-silk-white-body',
      name: 'Statuary Silk White Body 30×60',
      category: 'Ceramic & Mosaic',
      body: 'White Body',
      glazeFinish: 'Glazed',
      origin: 'Valencia, Spain',
      finish: 'Glazed',
      dimensions: '30 × 60 cm',
      sizeCategory: '30×60 cm',
      thickness: '9.5 mm',
      description: 'Prestige white body tile with luminous glazed surface and subtle silvery veins.',
      colorHex: '#f5f6f8',
      images: [
        '/assets/Stock Images/download (7).png',
        '/assets/Stock Images/download.png'
      ],
      features: ['Luminous white body backing', 'High light reflection index', 'Easy maintenance'],
      recommendedUse: 'Grand feature walls, luxury bathrooms, executive foyers'
    }
  ];

  static statistics: StatMetric[] = [
    {
      id: 'stat-countries',
      value: '28+',
      label: 'Countries Supplied',
      subtext: 'Global quarry partnerships & project deliveries across Europe, Middle East, and Asia.'
    },
    {
      id: 'stat-languages',
      value: '8',
      label: 'Languages Fluent In',
      subtext: 'Multilingual supply management in English, Polish, German, Italian, Spanish, Arabic, French & Mandarin.'
    },
    {
      id: 'stat-cities',
      value: '140+',
      label: 'Cities Delivered',
      subtext: 'Direct job site deliveries to major architectural capitals worldwide.'
    },
    {
      id: 'stat-sqft',
      value: '2.4M',
      label: 'Sq Ft Supplied To Date',
      subtext: 'Premium porcelain, marble, terrazzo, and sintered slabs installed in high-end developments.'
    },
    {
      id: 'stat-fastest',
      value: '18 hrs',
      label: 'Fastest Order Fulfillment',
      subtext: 'Record emergency stock dispatch from warehouse verification to freight loading.'
    },
    {
      id: 'stat-saved',
      value: '340+',
      label: 'Projects Saved From Stoppage',
      subtext: 'Prevented critical construction halts through accurate inventory auditing & fast supply line rescue.'
    },
    {
      id: 'stat-crisis',
      value: '94%',
      label: 'Crisis Orders Resolved',
      subtext: 'Orders successfully navigated through market shortages, factory delays, and custom shipping risks.'
    },
    {
      id: 'stat-consult',
      value: '88%',
      label: 'Consultation-Driven Projects',
      subtext: '88% of our client relationships start with technical specification dialogue rather than a raw direct order.'
    }
  ];

  static blogPosts: BlogPost[] = [
    {
      id: 'post-1',
      title: 'The Shortage of Certainty: Why Construction Projects Fail Before Tile Installation',
      category: 'Supply Strategy',
      date: 'July 2026',
      readTime: '4 min read',
      author: 'Supply Chain Specialist',
      excerpt: 'In the tile market, the main problem isn’t product scarcity — it’s the gap between what is announced and what actually exists in inventory.',
      content: [
        'A contractor once told us: "I didn’t buy the wrong tile; I made a decision based on wrong information." His project had come to a halt — not because of poor material quality, but because of uncertainty.',
        'In commerce, certain things cannot be understood from an invoice. No spreadsheet column reveals how anxious a developer was the night before a grand opening, and no item code explains why clients return a decade later.',
        'At Nirvana, we operate at the exact point in the supply chain where the decision is not yet final — where the smallest information error creates the largest exponential cost.'
      ],
      tags: ['Certainty', 'Inventory Audit', 'Supply Chain', 'Risk Management']
    },
    {
      id: 'post-2',
      title: 'Tiles Are the Last Thing Installed, But the First Thing Judged',
      category: 'Architectural Philosophy',
      date: 'June 2026',
      readTime: '5 min read',
      author: 'Materials Atelier Team',
      excerpt: 'A building is constructed from structural steel and concrete, but steel hides behind drywall. What remains is the surface — seen, touched, and walked upon.',
      content: [
        'In a warehouse, a veteran with over 40 years in construction told us something we never forgot: "Tiles are the last thing to be installed, but the first thing to be judged."',
        'That day, we understood our product isn’t just ceramic and glaze. We trade in people’s first impressions of a space.',
        'People don’t buy tiles; they buy peace of mind. They buy reputation. And they buy the confidence that today’s decision remains defensible years down the road.'
      ],
      tags: ['Interior Design', 'First Impressions', 'Porcelain', 'Craftsmanship']
    },
    {
      id: 'post-3',
      title: 'Velvet 60×60 Porcelain: The Technical Gold Standard for Wet Areas',
      category: 'Material Guide',
      date: 'May 2026',
      readTime: '6 min read',
      author: 'Technical Specifications Lead',
      excerpt: 'Why velvety micro-honed porcelain is replacing glossy glaze in luxury residential bathrooms and high-demand commercial kitchens.',
      content: [
        'Selecting tiles for wet rooms requires balancing tactile comfort against slip safety (R10 rating) and zero water absorption.',
        'Our flagship Velvet Porcelain 60×60 series achieves a soft touch while offering Mohs 8 scratch resistance and complete stain immunity.',
        'Tested across humid coastal villas and high-traffic hotel suites, Velvet provides monolithic aesthetic flow without sacrificing daily practical durability.'
      ],
      tags: ['Velvet Porcelain', 'Bathroom Design', 'Kitchen Tiles', 'Technical Spec']
    }
  ];
}
